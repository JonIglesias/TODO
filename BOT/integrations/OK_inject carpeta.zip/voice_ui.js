// File: voice_ui.js
(function () {
  const $ = (s, c) => (c || document).querySelector(s);
  const STORAGE_KEY = 'phs:dictation:on';

  let recog = null;
  let listening = false;

  // Estado del dictado/utterance actual
  let dictBuffer = '';        // texto confirmado (final)
  let utterId = 0;            // id creciente por utterance
  let sentForUtter = false;   // ya se envió en este utterance
  let lastSentHash = '';      // para evitar enviar lo mismo
  let sendTmo = null;

  // Render throttle
  let pendingValue = null;
  let renderScheduled = false;

  function supported() {
    return !!(window.SpeechRecognition || window.webkitSpeechRecognition);
  }

  function pageLang() {
    const lang = (document.documentElement.getAttribute('lang') || 'es').toLowerCase();
    if (lang.startsWith('en')) return 'en-US';
    if (lang.startsWith('fr')) return 'fr-FR';
    if (lang.startsWith('de')) return 'de-DE';
    if (lang.startsWith('it')) return 'it-IT';
    if (lang.startsWith('pt')) return 'pt-PT';
    if (lang.startsWith('nl')) return 'nl-NL';
    return 'es-ES';
  }

  function isChatOpen() {
    const card = $('#phsbot-root .phsbot-card');
    return card && card.getAttribute('data-open') === '1' && card.style.display !== 'none';
  }

  function scheduleRender(value) {
    pendingValue = value;
    if (renderScheduled) return;
    renderScheduled = true;
    // throttle suave para evitar parpadeo en sucesiones rápidas
    requestAnimationFrame(() => {
      const ta = $('#phsbot-q');
      if (ta && !sentForUtter && typeof pendingValue === 'string') {
        if (ta.value !== pendingValue) {
          ta.value = pendingValue;
          // mantén el cursor al final
          try { ta.selectionStart = ta.selectionEnd = ta.value.length; } catch {}
        }
      }
      renderScheduled = false;
    });
  }

  function ensureRecog() {
    if (recog) return recog;
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) return null;

    recog = new SR();
    recog.lang = pageLang();
    recog.continuous = true;
    recog.interimResults = true;
    recog.maxAlternatives = 1;

    recog.onstart = () => {
      newUtterance();
      $('#phs-voice-toggle')?.classList.add('listening');
    };

    recog.onresult = (ev) => {
      // 1) Construimos final + TODOS los interims del evento
      let interim = '';
      for (let i = ev.resultIndex; i < ev.results.length; i++) {
        const r = ev.results[i];
        const t = (r[0]?.transcript || '').trim();
        if (!t) continue;
        if (r.isFinal) {
          dictBuffer = dictBuffer ? (dictBuffer + ' ' + t) : t;
        } else {
          // acumula todos los interims recibidos en este batch
          interim += (interim ? ' ' : '') + t;
        }
      }

      // 2) Render: final + interim acumulado (sin borrar nunca)
      const nextVal = dictBuffer + (interim ? (dictBuffer ? ' ' : '') + interim : '');
      scheduleRender(nextVal);

      // 3) Si el último chunk fue final, programa envío único
      if (ev.results[ev.results.length - 1]?.isFinal) {
        scheduleSendOnce(utterId, 350);
      }
    };

    // Pausa de voz -> intenta enviar
    recog.onspeechend = () => {
      scheduleSendOnce(utterId, 250);
    };

    recog.onerror = (e) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        setToggle(false); return;
      }
      if (listening) {
        try { recog.stop(); } catch {}
        setTimeout(() => { if (listening && isChatOpen()) tryStart(); }, 600);
      }
    };

    recog.onend = () => {
      $('#phs-voice-toggle')?.classList.remove('listening');
      if (listening && isChatOpen()) setTimeout(tryStart, 120);
    };

    return recog;
  }

  function newUtterance() {
    utterId++;
    dictBuffer = '';
    sentForUtter = false;
    if (sendTmo) { clearTimeout(sendTmo); sendTmo = null; }
    pendingValue = null;
  }

  function tryStart() {
    const r = ensureRecog();
    if (!r) {
      alert('Tu navegador no soporta dictado por voz (SpeechRecognition).');
      setToggle(false);
      return;
    }
    try { r.lang = pageLang(); r.start(); } catch {}
  }

  function stop() {
    if (!recog) return;
    try { recog.stop(); } catch {}
  }

  function textHash(s) {
    let h = 0;
    for (let i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) | 0; }
    return String(h);
  }

  function scheduleSendOnce(id, delay) {
    if (sentForUtter) return;
    if (sendTmo) clearTimeout(sendTmo);
    sendTmo = setTimeout(() => {
      if (utterId !== id) return;
      doSendOnce();
    }, Math.max(0, delay || 0));
  }

  function doSendOnce() {
    if (sentForUtter) return;

    const ta = $('#phsbot-q');
    const sendBtn = $('#phsbot-send');
    if (!ta || !sendBtn) return;

    // Componer texto final (solo confirmado)
    const composed = (dictBuffer || ta.value || '').trim();
    if (!composed) return;

    // Anti-duplicado
    const h = textHash(composed);
    if (h === lastSentHash) {
      newUtterance(); // no limpiamos textarea porque no se envía de nuevo
      return;
    }

    sentForUtter = true;
    lastSentHash = h;

    // Asegura que el textarea muestra el final antes de enviar
    if (ta.value !== composed) ta.value = composed;

    // Enviar
    try { sendBtn.click(); } catch {}

    // Limpiar SOLO ahora (post-enviar)
    ta.value = '';
    newUtterance();
  }

  function setToggle(on) {
    const cb = document.querySelector('#phs-voice-ui input[type="checkbox"]');
    const label = document.querySelector('#phs-voice-ui label');
    listening = !!on;

    if (cb) cb.checked = listening;
    if (label) label.classList.toggle('is-on', listening);
    localStorage.setItem(STORAGE_KEY, listening ? '1' : '0');

    if (listening) {
      if (!supported()) {
        alert('Tu navegador no soporta dictado por voz.');
        listening = false;
        if (cb) cb.checked = false;
        if (label) label.classList.remove('is-on');
        return;
      }
      if (isChatOpen()) tryStart();
    } else {
      stop();
    }
  }

  function bindCardObserver(card) {
    if (!card) return;
    const mo = new MutationObserver(() => {
      if (!listening) return;
      if (isChatOpen()) tryStart(); else stop();
    });
    mo.observe(card, { attributes: true, attributeFilter: ['data-open', 'style'] });
  }

  function init() {
    const cb = document.querySelector('#phs-voice-ui input[type="checkbox"]');
    const label = document.querySelector('#phs-voice-ui label');
    const card = $('#phsbot-root .phsbot-card');
    if (!cb || !label || !card) return false;

    const saved = localStorage.getItem(STORAGE_KEY) === '1';
    setToggle(saved);

    cb.addEventListener('change', () => setToggle(cb.checked));
    ['click', 'mousedown'].forEach(ev =>
      label.addEventListener(ev, e => e.stopPropagation(), true)
    );

    bindCardObserver(card);

    document.addEventListener('visibilitychange', () => {
      if (!listening) return;
      if (document.hidden) stop(); else if (isChatOpen()) tryStart();
    });

    if (location.protocol !== 'https:' && location.hostname !== 'localhost') {
      console.warn('[PHS Dictado] La API de voz puede requerir HTTPS para permisos de micrófono.');
    }
    return true;
  }

  (function wait() { if (!init()) setTimeout(wait, 200); })();
})();