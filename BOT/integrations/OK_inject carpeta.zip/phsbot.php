<?php
/**
 * Plugin Name: PHSBOT
 * Description: Núcleo de ajustes para el chatbot de Pro Hunting Spain (solo configuración).
 * Version: 1.2.1
 * Author: Pro Hunting Spain
 * License: GPLv2 or later
 */

if (!defined('ABSPATH')) exit;

// Evita redefinir la clase; pero NO hagas return, para no cortar los requires de abajo.
if (!class_exists('PHSBOT_Plugin')) {
    class PHSBOT_Plugin {

        const OPTION_KEY   = 'phsbot_settings';
        const OPTION_GROUP = 'phsbot_settings_group';
        const PAGE_SLUG    = 'phsbot-settings'; // slug interno de la página de secciones/campos (no menú)

        function __construct() {
            add_action('admin_init', array($this, 'register_settings'));
            add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_assets'));
            add_filter('plugin_action_links_' . plugin_basename(__FILE__), array($this, 'settings_link'));
            add_action('plugins_loaded', array($this, 'ensure_defaults_and_migrate'));
        }

        /* ===== Helpers públicos ===== */

        static function get_settings() {
            $defaults = self::defaults();
            $opt = get_option(self::OPTION_KEY, array());
            if (!is_array($opt)) $opt = array();
            return wp_parse_args($opt, $defaults);
        }

        static function get_setting($key, $default = null) {
            $all = self::get_settings();
            return array_key_exists($key, $all) ? $all[$key] : $default;
        }

        static function get_allowed_domains() {
            $s = self::get_settings();
            return (isset($s['allowed_domains']) && is_array($s['allowed_domains'])) ? $s['allowed_domains'] : array();
        }

        function register_settings() {
            register_setting(self::OPTION_GROUP, self::OPTION_KEY, array(
                'type' => 'array',
                'sanitize_callback' => array($this, 'sanitize_settings'),
                'default' => self::defaults(),
            ));

            add_settings_section('phs_section_general', 'General', '__return_false', self::PAGE_SLUG);
            add_settings_section('phs_section_integrations', 'Integraciones', '__return_false', self::PAGE_SLUG);
            add_settings_section('phs_section_appearance', 'Apariencia', '__return_false', self::PAGE_SLUG);
            add_settings_section('phs_section_sources', 'Fuentes de datos (crawler)', '__return_false', self::PAGE_SLUG);

            // General
            add_settings_field('chat_active', 'Estado del chat', array($this, 'field_chat_active'), self::PAGE_SLUG, 'phs_section_general');
            add_settings_field('chat_position', 'Posición del chatbot', array($this, 'field_chat_position'), self::PAGE_SLUG, 'phs_section_general');
            add_settings_field('chat_width', 'Anchura del chat', array($this, 'field_chat_width'), self::PAGE_SLUG, 'phs_section_general');
            add_settings_field('chat_height', 'Altura del chat', array($this, 'field_chat_height'), self::PAGE_SLUG, 'phs_section_general');

            // Integraciones
            add_settings_field('openai_api_key', 'Token de ChatGPT (OpenAI API Key)', array($this, 'field_openai_api_key'), self::PAGE_SLUG, 'phs_section_integrations');
            add_settings_field('telegram_bot_token', 'Token de Telegram (Bot)', array($this, 'field_telegram_bot_token'), self::PAGE_SLUG, 'phs_section_integrations');
            add_settings_field('telegram_chat_id', 'ID de Telegram (chat/user/channel)', array($this, 'field_telegram_chat_id'), self::PAGE_SLUG, 'phs_section_integrations');
            add_settings_field('whatsapp_phone', 'Teléfono de WhatsApp (derivación)', array($this, 'field_whatsapp_phone'), self::PAGE_SLUG, 'phs_section_integrations');

            // Apariencia
            add_settings_field('palette', 'Paleta predefinida', array($this, 'field_palette'), self::PAGE_SLUG, 'phs_section_appearance');
            add_settings_field('color_primary', 'Color primario', array($this, 'field_color_primary'), self::PAGE_SLUG, 'phs_section_appearance');
            add_settings_field('color_secondary', 'Color secundario', array($this, 'field_color_secondary'), self::PAGE_SLUG, 'phs_section_appearance');
            add_settings_field('color_background', 'Fondo del chat', array($this, 'field_color_background'), self::PAGE_SLUG, 'phs_section_appearance');
            add_settings_field('color_text', 'Texto principal', array($this, 'field_color_text'), self::PAGE_SLUG, 'phs_section_appearance');
            add_settings_field('color_bot_bubble', 'Burbuja BOT', array($this, 'field_color_bot_bubble'), self::PAGE_SLUG, 'phs_section_appearance');
            add_settings_field('color_user_bubble', 'Burbuja USUARIO', array($this, 'field_color_user_bubble'), self::PAGE_SLUG, 'phs_section_appearance');

            // Fuentes
            add_settings_field('allowed_domains', 'Dominios permitidos (uno por línea)', array($this, 'field_allowed_domains'), self::PAGE_SLUG, 'phs_section_sources');
        }

        function enqueue_admin_assets($hook) {
            // Encola assets en todas las pantallas del plugin (toplevel + submenús)
            $allow = array('toplevel_page_phsbot', 'settings_page_phsbot', 'toplevel_page_' . self::PAGE_SLUG);
            if (!in_array($hook, $allow, true)) {
                $screen = function_exists('get_current_screen') ? get_current_screen() : null;
                if ($screen && ( $screen->id === 'toplevel_page_phsbot' || strpos($screen->id, 'phsbot_page_') === 0 )) {
                    // ok
                } else {
                    return;
                }
            }

            wp_enqueue_style('wp-color-picker');
            wp_enqueue_script('wp-color-picker');

            // IMPORTANTE: NOWDOC para evitar interpolación de $i dentro del JS
            $inline_js = <<<'JS'
(function($){
    $(function(){
        $('.phs-color').wpColorPicker();
        var palettes = {
            none:{},
            phs_dark:{color_primary:'#7A1C1C',color_secondary:'#C4A484',color_background:'#121212',color_text:'#EFEFEF',color_bot_bubble:'#1F1F1F',color_user_bubble:'#2B2B2B'},
            phs_light:{color_primary:'#8A2B2B',color_secondary:'#D7C1A5',color_background:'#FFFFFF',color_text:'#1A1A1A',color_bot_bubble:'#F3F3F3',color_user_bubble:'#EDE7E1'},
            forest:{color_primary:'#1F5D3A',color_secondary:'#A6B37D',color_background:'#0E1A14',color_text:'#E7F0E9',color_bot_bubble:'#15241C',color_user_bubble:'#1E3628'},
            desert:{color_primary:'#A66A2C',color_secondary:'#D9C4A1',color_background:'#FFF9F0',color_text:'#2B2116',color_bot_bubble:'#F1E3CC',color_user_bubble:'#E7D4B6'}
        };
        $('#palette').on('change', function(){
            var set = palettes[$(this).val()]||{};
            for (var key in set) {
                var $i = $('input[name="phsbot_settings['+key+']"]');
                if ($i.length){
                    $i.val(set[key]).trigger('change');
                    try{ if($i.data('wpWpColorPicker')){ $i.wpColorPicker('color', set[key]); } }catch(e){}
                }
            }
        });
    });
})(jQuery);
JS;
            wp_add_inline_script('wp-color-picker', $inline_js);
            wp_add_inline_style('wp-color-picker', '.phs-wide{width:420px;max-width:100%}.phs-domains{width:520px;max-width:100%;min-height:140px}.description{opacity:.8}');
        }

        function settings_link($links) {
            // Apunta al menú "PhsBot"
            $url = admin_url('admin.php?page=phsbot');
            $links[] = '<a href="' . esc_url($url) . '">Ajustes</a>';
            return $links;
        }

        /* ===== Render (respaldo) ===== */
        function render_settings_page() {
            if (!current_user_can('manage_options')) return;
            ?>
            <div class="wrap">
                <h1>PHSBOT — Ajustes base</h1>
                <form method="post" action="options.php">
                    <?php
                    settings_fields(self::OPTION_GROUP);
                    do_settings_sections(self::PAGE_SLUG);
                    submit_button('Guardar ajustes');
                    ?>
                </form>
            </div>
            <?php
        }

        /* ===== Fields ===== */
        static function e($key) {
            $s = self::get_settings();
            return isset($s[$key]) ? $s[$key] : '';
        }

        function field_chat_active() { $v = (bool) self::e('chat_active'); ?>
            <label><input type="checkbox" name="<?php echo esc_attr(self::OPTION_KEY); ?>[chat_active]" value="1" <?php checked($v, true); ?>> Activar el chatbot en el front</label>
        <?php }

        function field_chat_position() {
            $v = (string) self::e('chat_position');
            $options = array(
                'bottom-right' => 'Flotante — Abajo derecha',
                'bottom-left'  => 'Flotante — Abajo izquierda',
                'top-right'    => 'Flotante — Arriba derecha',
                'top-left'     => 'Flotante — Arriba izquierda',
                'inline'       => 'Inline (embebido)'
            );
            echo '<select name="'.esc_attr(self::OPTION_KEY).'[chat_position]">';
            foreach ($options as $val => $label) {
                echo '<option value="'.esc_attr($val).'" '.selected($v, $val, false).'>'.esc_html($label).'</option>';
            }
            echo '</select><p class="description">Se podrá sobrescribir por shortcode/Elementor.</p>';
        }

        function field_chat_width()  { $v = (string) self::e('chat_width'); ?>
            <input class="regular-text phs-wide" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[chat_width]" value="<?php echo esc_attr($v); ?>" placeholder="360px, 100%, 80vw">
            <p class="description">Unidades: px, %, vw.</p>
        <?php }

        function field_chat_height() { $v = (string) self::e('chat_height'); ?>
            <input class="regular-text phs-wide" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[chat_height]" value="<?php echo esc_attr($v); ?>" placeholder="520px, 70vh">
            <p class="description">Unidades: px, vh.</p>
        <?php }

        function field_openai_api_key() { $v = (string) self::e('openai_api_key'); ?>
            <input class="regular-text phs-wide" type="password" name="<?php echo esc_attr(self::OPTION_KEY); ?>[openai_api_key]" value="<?php echo esc_attr($v); ?>" autocomplete="off">
            <p class="description">Clave de OpenAI.</p>
        <?php }

        function field_telegram_bot_token() { $v = (string) self::e('telegram_bot_token'); ?>
            <input class="regular-text phs-wide" type="password" name="<?php echo esc_attr(self::OPTION_KEY); ?>[telegram_bot_token]" value="<?php echo esc_attr($v); ?>" autocomplete="off">
        <?php }

        function field_telegram_chat_id() { $v = (string) self::e('telegram_chat_id'); ?>
            <input class="regular-text phs-wide" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[telegram_chat_id]" value="<?php echo esc_attr($v); ?>">
        <?php }

        function field_whatsapp_phone() { $v = (string) self::e('whatsapp_phone'); ?>
            <input class="regular-text phs-wide" type="text" name="<?php echo esc_attr(self::OPTION_KEY); ?>[whatsapp_phone]" value="<?php echo esc_attr($v); ?>" placeholder="+346XXXXXXXX">
            <p class="description">Formato internacional (+34...).</p>
        <?php }

        function field_palette() {
            $v = (string) self::e('palette');
            $options = array(
                'none'      => 'Sin paleta (manual)',
                'phs_dark'  => 'PHS Dark (vino/arena oscuro)',
                'phs_light' => 'PHS Light (vino/arena claro)',
                'forest'    => 'Forest (verdes)',
                'desert'    => 'Desert (ocres)',
            );
            echo '<select id="palette" name="'.esc_attr(self::OPTION_KEY).'[palette]">';
            foreach ($options as $val => $label) {
                echo '<option value="'.esc_attr($val).'" '.selected($v, $val, false).'>'.esc_html($label).'</option>';
            }
            echo '</select><p class="description">Autorrellena colores base.</p>';
        }

        function field_color_primary()   { $this->render_color('color_primary'); }
        function field_color_secondary() { $this->render_color('color_secondary'); }
        function field_color_background(){ $this->render_color('color_background'); }
        function field_color_text()      { $this->render_color('color_text'); }
        function field_color_bot_bubble(){ $this->render_color('color_bot_bubble'); }
        function field_color_user_bubble(){ $this->render_color('color_user_bubble'); }

        function render_color($key) {
            $v = (string) self::e($key);
            echo '<input class="phs-color" type="text" name="'.esc_attr(self::OPTION_KEY).'['.esc_attr($key).']" value="'.esc_attr($v).'" data-default-color="'.esc_attr(self::defaults()[$key]).'">';
        }

        function field_allowed_domains() {
            $text = implode("\n", self::get_allowed_domains());
            echo '<textarea class="phs-domains" name="'.esc_attr(self::OPTION_KEY).'[allowed_domains]">'.esc_textarea($text).'</textarea>';
            echo '<p class="description">Uno por línea. Ej: <code>prohuntingspain.com</code> o <code>blog.prohuntingspain.com</code>.</p>';
        }

        /* ===== Sanitización ===== */

        function sanitize_settings($input) {
            $out = self::defaults();

            $out['chat_active'] = !empty($input['chat_active']);

            $allowed_positions = array('bottom-right','bottom-left','top-right','top-left','inline');
            $pos = isset($input['chat_position']) ? sanitize_text_field($input['chat_position']) : $out['chat_position'];
            $out['chat_position'] = in_array($pos, $allowed_positions, true) ? $pos : $out['chat_position'];

            $out['chat_width']  = $this->sanitize_css_size(isset($input['chat_width']) ? $input['chat_width'] : $out['chat_width']);
            $out['chat_height'] = $this->sanitize_css_size(isset($input['chat_height']) ? $input['chat_height'] : $out['chat_height']);

            $out['openai_api_key']     = $this->sanitize_token(isset($input['openai_api_key']) ? $input['openai_api_key'] : '');
            $out['telegram_bot_token'] = $this->sanitize_token(isset($input['telegram_bot_token']) ? $input['telegram_bot_token'] : '');
            $out['telegram_chat_id']   = sanitize_text_field(isset($input['telegram_chat_id']) ? $input['telegram_chat_id'] : '');

            $wa = isset($input['whatsapp_phone']) ? (string)$input['whatsapp_phone'] : '';
            $wa = preg_replace('/[^0-9\+]/', '', $wa);
            $out['whatsapp_phone'] = ltrim($wa);

            $pal = isset($input['palette']) ? sanitize_text_field($input['palette']) : 'none';
            $out['palette'] = in_array($pal, array('none','phs_dark','phs_light','forest','desert'), true) ? $pal : 'none';

            foreach (array('color_primary','color_secondary','color_background','color_text','color_bot_bubble','color_user_bubble') as $ck) {
                $c = isset($input[$ck]) ? $input[$ck] : self::defaults()[$ck];
                $out[$ck] = $this->sanitize_hex_color_fallback($c, self::defaults()[$ck]);
            }

            $raw_domains = isset($input['allowed_domains']) ? $input['allowed_domains'] : '';
            $out['allowed_domains'] = $this->sanitize_domains($raw_domains);

            return $out;
        }

        function sanitize_css_size($val) {
            $val = trim((string)$val);
            if ($val === '') return '';
            if (preg_match('/^\d+(\.\d+)?(px|%|vh|vw)$/i', $val)) return $val;
            return '360px';
        }

        function sanitize_token($val) {
            $val = trim((string)$val);
            $val = wp_kses($val, array());
            return preg_replace('/\s+/', '', $val);
        }

        function sanitize_hex_color_fallback($color, $fallback) {
            $color = trim((string)$color);
            if (preg_match('/^#([A-Fa-f0-9]{3}){1,2}$/', $color)) return $color;
            return $fallback;
        }

        function sanitize_domains($raw) {
            $list = is_array($raw) ? $raw : preg_split('/\r\n|\r|\n/', (string)$raw);
            $clean = array();
            foreach ($list as $line) {
                $d = strtolower(trim($line));
                if ($d === '') continue;
                if (strpos($d, 'http://') === 0 || strpos($d, 'https://') === 0) {
                    $host = parse_url($d, PHP_URL_HOST);
                    if ($host) $d = $host;
                }
                if (preg_match('/^([a-z0-9-]+\.)+[a-z]{2,}$/', $d)) $clean[] = $d;
            }
            return array_values(array_unique($clean));
        }

        /* ===== Defaults & migración ===== */

        static function defaults() {
            return array(
                'chat_active'      => true,
                'chat_position'    => 'bottom-right',
                'chat_width'       => '360px',
                'chat_height'      => '520px',

                'openai_api_key'     => '',
                'telegram_bot_token' => '',
                'telegram_chat_id'   => '',
                'whatsapp_phone'     => '',

                'palette'          => 'none',
                'color_primary'    => '#7A1C1C',
                'color_secondary'  => '#C4A484',
                'color_background' => '#FFFFFF',
                'color_text'       => '#1A1A1A',
                'color_bot_bubble' => '#F3F3F3',
                'color_user_bubble'=> '#EDE7E1',

                'allowed_domains'  => array('prohuntingspain.com'),
            );
        }

        function ensure_defaults_and_migrate() {
            $cur = get_option(self::OPTION_KEY, null);
            if ($cur === null) {
                $old = get_option('phs_chatbot_settings', null);
                if (is_array($old)) {
                    $merged = wp_parse_args($old, self::defaults());
                    add_option(self::OPTION_KEY, $merged, '', 'no'); // autoload NO
                } else {
                    add_option(self::OPTION_KEY, self::defaults(), '', 'no'); // autoload NO
                }
            } elseif (is_array($cur)) {
                $merged = wp_parse_args($cur, self::defaults());
                if ($merged !== $cur) update_option(self::OPTION_KEY, $merged);
            }
        }
    }
    new PHSBOT_Plugin();
}

// Cargar el hub (incluye módulos)
require_once __DIR__ . '/common.php';


/**
 * Alias de compatibilidad para evitar fatal si algún submenú/hook
 * aún apunta a 'phsbot_render_kb_page'. Redirige al render nuevo
 * si existe; si no, muestra un mensaje amable y no rompe.
 */
