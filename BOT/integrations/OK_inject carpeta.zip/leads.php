<?php
// File: leads.php
if (!defined('ABSPATH')) exit;

/**
 * Almacenamiento en wp_options:
 *  - phsbot_leads_store: array de leads por CID
 *    lead = [
 *      'cid'         => string,
 *      'first_seen'  => 'Y-m-d H:i:s',
 *      'last_seen'   => 'Y-m-d H:i:s',
 *      'score'       => int 0..10,
 *      'rationale'   => string,
 *      'email'       => string|null,
 *      'phone'       => string|null,
 *      'name'        => string|null,
 *      'page'        => string (url),
 *      'messages'    => [['t'=>ts,'role'=>'user|assistant','text'=>string], ...],
 *      'notified'    => ['telegram'=>int,'email_instant'=>int,'email_final'=>int],
 *      'telegram_msg_id' => int,
 *      'summary'     => string,
 *      'summary_updated' => int,
 *      'view_token'  => string,
 *      'closed'      => int,
 *      'last_change_ts' => int,
 *    ]
 */

define('PHSBOT_LEADS_STORE', 'phsbot_leads_store');
define('PHSBOT_LEADS_GROUP', 'phsbot_leads_group');
define('PHSBOT_LEADS_OPT',   'phsbot_leads_settings');

// Fuerza reset del almacenamiento en navegador de los clientes
define('PHSBOT_CLIENT_RESET_OPT', 'phsbot_client_reset_version');
function phsbot_client_bump_reset(){
    update_option(PHSBOT_CLIENT_RESET_OPT, time());
}

/** ================ Helpers base config global ================ */
if (!function_exists('phsbot_setting')) {
    function phsbot_setting($key, $default = '') {
        $opt = get_option('phsbot_settings', array());
        return isset($opt[$key]) ? $opt[$key] : $default;
    }
}

/** ================ Defaults & getters ================ */
function phsbot_leads_defaults() {
    return array(
        'scoring_prompt' => "Eres un asistente que puntúa intención de compra en 0..10 a partir de un histórico de chat (Cliente/Agente). Considera señales: ofrecer teléfono/email, preguntas de precio, fechas, alojamientos, disponibilidad, urgencia. 0-3: curiosidad; 4-6: interés tibio; 7-8: intención clara; 9-10: compra inminente.\nDevuelve SOLO un JSON: {\"score\": X, \"rationale\": \"...\"}",
        // Umbrales legacy (no usados en la nueva lógica inmediata)
        'telegram_threshold'       => 9,
        'email_instant_threshold'  => 7,
        'email_daily_threshold'    => 5,
        'reevaluate_each_message'  => 1,
        'escalate_on_upgrade'      => 1,
        'daily_summary_email'      => '',
        'telegram_token_override'  => '',
        'telegram_chat_id_override'=> '',
    );
}
function phsbot_leads_get_settings() {
    $cur = get_option(PHSBOT_LEADS_OPT, array());
    if (!is_array($cur)) $cur = array();
    return wp_parse_args($cur, phsbot_leads_defaults());
}
function phsbot_leads_save_settings($arr){
    update_option(PHSBOT_LEADS_OPT, $arr);
}

/** ================ Store helpers (memoria) ================ */
function phsbot_leads_all(){
    $all = get_option(PHSBOT_LEADS_STORE, array());
    return is_array($all) ? $all : array();
}
function phsbot_leads_put_all($all){
if (get_option(PHSBOT_LEADS_STORE, null) === null) {
        add_option(PHSBOT_LEADS_STORE, is_array($all)?$all:array(), '', 'no'); // autoload NO
    } else {
        update_option(PHSBOT_LEADS_STORE, is_array($all)?$all:array());
    }
}
function phsbot_leads_get($cid){
    $all = phsbot_leads_all();
    return isset($all[$cid]) && is_array($all[$cid]) ? $all[$cid] : null;
}
function phsbot_leads_put($cid, $lead){
    $all = phsbot_leads_all();
    $all[$cid] = $lead;
    phsbot_leads_put_all($all);
}
function phsbot_leads_delete_many($cids){
    $all = phsbot_leads_all();
    foreach ($cids as $cid) { unset($all[$cid]); }
    phsbot_leads_put_all($all);
}
function phsbot_leads_clear_all(){
    delete_option(PHSBOT_LEADS_STORE);
    add_option(PHSBOT_LEADS_STORE, array(), '', 'no');
}
function phsbot_leads_purge_closed_before($days){
    $days = max(1, intval($days));
    $cut  = time() - ($days*DAY_IN_SECONDS);
    $all  = phsbot_leads_all();
    foreach ($all as $cid => $lead){
        $closed = !empty($lead['closed']);
        $last   = !empty($lead['last_seen']) ? strtotime($lead['last_seen']) : 0;
        if ($closed && $last && $last < $cut) unset($all[$cid]);
    }
    phsbot_leads_put_all($all);
}

/** ================ Extractores básicos ================ */
// === Nombre (extrae "me llamo", "soy", "Nombre:")
function phsbot_clean_name($s){
    $s = trim(preg_replace('/\s+/', ' ', $s));
    if (function_exists('mb_convert_case')) $s = mb_convert_case($s, MB_CASE_TITLE, "UTF-8");
    return $s;
}
function phsbot_extract_name($text){
    $t = trim(preg_replace('/\s+/', ' ', (string)$text));
    if ($t === '') return null;

    // 1) “me llamo[:]? …” / “soy[:]? …” / “mi nombre es …” / “my name is …”
    if (preg_match('/\b(?:me\s+llamo|soy|mi\s+nombre\s+es|my\s+name\s+is)\s*[:\-–—]?\s+([A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ\'\-\s]{1,60})/iu', $t, $m)) {
        $name = trim($m[1]);
        $name = preg_replace('/\s{2,}/', ' ', $name);
        $name = preg_replace('/[\s\.,;:!\?)\]\-–—]+$/u', '', $name);
        return phsbot_clean_name($name);
    }

    // 2) “nombre: …” / “name - …”
    if (preg_match('/\b(?:nombre|name)\s*[:\-–—]\s*([A-Za-zÁÉÍÓÚÜÑáéíóúüñ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ\'\-\s]{1,60})/iu', $t, $m)) {
        $name = trim($m[1]);
        $name = preg_replace('/[\s\.,;:!\?)\]\-–—]+$/u', '', $name);
        return phsbot_clean_name($name);
    }

    // 3) Fallback: solo un nombre propio (1-2 palabras capitalizadas)
    if (!preg_match('/@|\d/', $t) && preg_match('/^\s*[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ\'\-]{1,40}(?:\s+[A-ZÁÉÍÓÚÜÑ][A-Za-zÁÉÍÓÚÜÑáéíóúüñ\'\-]{1,40})?\s*$/u', $t)) {
        $name = preg_replace('/[\s\.,;:!\?)\]\-–—]+$/u', '', $t);
        return phsbot_clean_name($name);
    }
    return null;
}
// === Backfill: intenta obtener el nombre desde el histórico (últimos primero)
function phsbot_leads_backfill_name(array $messages){
    if (empty($messages) || !is_array($messages)) return null;
    for ($i = count($messages)-1; $i >= 0; $i--) {
        $m = $messages[$i];
        if (($m['role'] ?? '') === 'user' && !empty($m['text'])) {
            $nm = phsbot_extract_name($m['text']);
            if ($nm) return $nm;
        }
    }
    return null;
}

function phsbot_extract_email($text){
    if (preg_match('/[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i', $text, $m)) return $m[0];
    return null;
}
function phsbot_extract_phone($text){
    if (preg_match('/(\+?\d[\d\s().-]{6,}\d)/', $text, $m)) return trim($m[1]);
    return null;
}
function phsbot_contains_keywords($text){
    $k = array('precio','precios','tarifa','coste','cuánto','fecha','fechas','disponibilidad','reserva','reservar','contratar','oferta','presupuesto');
    $t = mb_strtolower($text);
    foreach ($k as $w){ if (strpos($t, $w) !== false) return true; }
    return false;
}

/** ================ Scoring con LLM (compat) ================ */
function phsbot_leads_score_with_llm($lead){
    $s = phsbot_leads_get_settings();
    $api_key = (string) phsbot_setting('openai_api_key', '');
    if (!$api_key) {
        // fallback: heurística rápida
        $base = 1;
        if (!empty($lead['email'])) $base += 5;
        if (!empty($lead['phone'])) $base += 8;
        if (!empty($lead['email']) && !empty($lead['phone'])) $base = max($base, 9);
        $last = end($lead['messages']);
        if ($last && ($last['role']??'')==='user' && phsbot_contains_keywords($last['text']??'')) $base += 2;
        return array('score'=>min(10,$base), 'rationale'=>'(heurística sin LLM)');
    }

    $model  = (string) phsbot_setting('leads_model', 'gpt-4o-mini');
    $prompt = (string) $s['scoring_prompt'];

    // histórico compacto
    $buff = array(); $chars=0;
    foreach ($lead['messages'] as $m){
        $role = ($m['role']??'user')==='user' ? 'Cliente' : 'Agente';
        $line = $role . ': ' . trim(preg_replace('/\s+/',' ', (string)($m['text']??'')));
        $buff[]=$line; $chars+=strlen($line);
        if ($chars>2000) break;
    }
    $context = implode("\n",$buff);

    $res = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
        'timeout' => 15,
        'headers' => array('Authorization'=>'Bearer '.$api_key, 'Content-Type'=>'application/json'),
        'body' => wp_json_encode(array(
            'model'=>$model,
            'messages'=>array(
                array('role'=>'system','content'=>$prompt),
                array('role'=>'user','content'=>$context),
            ),
            'temperature'=>0.2,
            'max_tokens'=>120,
        )),
    ));
    $json = array('score'=>0,'rationale'=>'');
    if (!is_wp_error($res) && wp_remote_retrieve_response_code($res)===200){
        $body = json_decode(wp_remote_retrieve_body($res), true);
        $text = trim($body['choices'][0]['message']['content'] ?? '');
        $dec  = json_decode($text, true);
        if (is_array($dec) && isset($dec['score'])) {
            $json['score'] = max(0, min(10, intval($dec['score'])));
            $json['rationale'] = isset($dec['rationale']) ? (string)$dec['rationale'] : '';
        } else {
            $json['rationale'] = $text;
        }
    }
    return $json;
}

/** ================ Email & Telegram ================ */
function phsbot_notify_email($to, $subject, $body){
    if (!$to) return false;
    $headers = array('Content-Type: text/html; charset=UTF-8');
    return wp_mail($to, $subject, wpautop($body), $headers);
}
function phsbot_telegram_send($token, $chat_id, $text){
    if (!$token || !$chat_id || !$text) return false;
    $res = wp_remote_post("https://api.telegram.org/bot{$token}/sendMessage", array(
        'timeout' => 12,
        'body' => array(
            'chat_id' => $chat_id,
            'text' => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        )
    ));
    if (is_wp_error($res)) return false;
    if (wp_remote_retrieve_response_code($res)!==200) return false;
    $body = json_decode(wp_remote_retrieve_body($res), true);
    return isset($body['ok'],$body['result']['message_id']) && $body['ok'] ? intval($body['result']['message_id']) : false;
}
function phsbot_telegram_edit($token, $chat_id, $message_id, $text){
    if (!$token || !$chat_id || !$message_id || !$text) return false;
    $res = wp_remote_post("https://api.telegram.org/bot{$token}/editMessageText", array(
        'timeout' => 12,
        'body' => array(
            'chat_id' => $chat_id,
            'message_id' => $message_id,
            'text' => $text,
            'parse_mode' => 'HTML',
            'disable_web_page_preview' => true,
        )
    ));
    return !is_wp_error($res) && wp_remote_retrieve_response_code($res)===200;
}

/** ================ Resumen IA de la conversación ================ */
function phsbot_leads_summarize_chat(array $lead){
    if (!empty($lead['summary']) && !empty($lead['summary_updated']) && (time()-intval($lead['summary_updated'])<120)) {
        return (string)$lead['summary'];
    }
    $api_key = (string) phsbot_setting('openai_api_key', '');
    $msgs = isset($lead['messages']) && is_array($lead['messages']) ? $lead['messages'] : array();
    if (!$api_key || count($msgs)===0){
        $last = end($msgs);
        $txt  = $last && !empty($last['text']) ? wp_trim_words($last['text'], 40) : 'Interacción breve sin detalles';
        return "Interés en servicios de caza. Última interacción: “{$txt}”.";
    }
    $buff=array();
    foreach($msgs as $m){
        $role = ($m['role']??'user')==='user'?'Cliente':'Agente';
        $buff[] = "{$role}: ".trim(preg_replace('/\s+/', ' ', (string)($m['text'] ?? '')));
        if (strlen(implode("\n",$buff))>1500) break;
    }
    $context = implode("\n",$buff);
    $prompt = "Resume en 2-3 frases, directas y útiles para ventas, la intención y temas clave del chat.\n".
              "Enfatiza especie/servicio de interés y puntos logísticos (fechas, alojamiento, familia, presupuesto si aparecieron).\n".
              "No inventes datos. Español. Devuelve solo el resumen, sin viñetas.";
    $model = (string) phsbot_setting('leads_model', 'gpt-4o-mini');
    $res = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
        'timeout'=>15,
        'headers'=>array('Authorization'=>'Bearer '.$api_key,'Content-Type'=>'application/json'),
        'body'=>wp_json_encode(array(
            'model'=>$model,
            'messages'=>array(
                array('role'=>'system','content'=>$prompt),
                array('role'=>'user','content'=>$context),
            ),
            'temperature'=>0.3,
            'max_tokens'=>160,
        )),
    ));
    if (is_wp_error($res) || wp_remote_retrieve_response_code($res)!==200){
        $last = end($msgs);
        $txt  = $last && !empty($last['text']) ? wp_trim_words($last['text'], 40) : 'Interacción breve sin detalles';
        return "Interés en servicios de caza. Última interacción: “{$txt}”.";
    }
    $body = json_decode(wp_remote_retrieve_body($res), true);
    $out  = trim($body['choices'][0]['message']['content'] ?? '');
    return $out ?: 'Interés general detectado; falta detalle.';
}

/** ================ Enlace público para ver chat completo ================ */
function phsbot_leads_get_view_link(array &$lead){
    if (empty($lead['view_token'])) {
        $lead['view_token'] = wp_generate_password(32, false, false);
        phsbot_leads_put($lead['cid'], $lead);
    }
    return add_query_arg(array('phsbot_view_chat' => $lead['view_token']), home_url('/'));
}

/** ================ Endpoint público lectura chat ================ */
add_action('init', function(){
    if (!empty($_GET['phsbot_view_chat'])) {
        $token = sanitize_text_field($_GET['phsbot_view_chat']);
        $all = phsbot_leads_all();
        $lead = null;
        foreach ($all as $L){
            if (!empty($L['view_token']) && hash_equals($L['view_token'], $token)) { $lead = $L; break; }
        }
        if (!$lead){
            status_header(404);
            echo '<!doctype html><meta charset="utf-8"><h1>Chat no encontrado</h1>';
            exit;
        }
        echo '<!doctype html><meta charset="utf-8"><title>Chat PHS</title>';
?>
<style>
:root{
  --chat-bg:#fafafa; --agent-bg:#fff; --agent-border:#e6e6e6;
  --user-bg:#2563eb; --user-text:#fff; --text:#111827; --muted:#6b7280;
  --shadow:0 4px 14px rgba(0,0,0,.08);
}
@media (prefers-color-scheme: dark){
  :root{
    --chat-bg:#0b0f14; --agent-bg:#121821; --agent-border:#1f2937;
    --user-bg:#3b82f6; --user-text:#f8fafc; --text:#e5e7eb; --muted:#94a3b8;
    --shadow:0 6px 18px rgba(0,0,0,.35);
  }
}
body.phs-chat-view{background:var(--chat-bg);color:var(--text);
  font:15px system-ui,-apple-system,Segoe UI,Roboto,sans-serif;margin:20px;}
.phs-chat-wrap{max-width:920px;margin:0 auto;}
.phs-chat-title{font-size:20px;font-weight:700;margin:0 0 14px;}
.phs-chat{display:flex;flex-direction:column;gap:10px;}
.phs-msg{display:flex;align-items:flex-end;}
.phs-msg.agent{justify-content:flex-start;}
.phs-msg.user{justify-content:flex-end;}
.phs-bubble{position:relative;max-width:78%;padding:10px 12px;border-radius:16px;
  box-shadow:var(--shadow);line-height:1.4;overflow-wrap:anywhere;word-wrap:break-word;
  border:1px solid var(--agent-border);}
.phs-msg.agent .phs-bubble{background:var(--agent-bg);color:var(--text);border-top-left-radius:6px;}
.phs-msg.agent .phs-bubble::after{content:"";position:absolute;left:-8px;bottom:0;width:10px;height:12px;
  background:linear-gradient(135deg,transparent 0 50%,var(--agent-bg) 50% 100%);}
.phs-msg.user .phs-bubble{background:var(--user-bg);color:var(--user-text);border-color:transparent;border-top-right-radius:6px;}
.phs-msg.user .phs-bubble::after{content:"";position:absolute;right:-8px;bottom:0;width:10px;height:12px;
  background:linear-gradient(225deg,transparent 0 50%,var(--user-bg) 50% 100%);}
.phs-meta{font-size:12px;color:var(--muted);margin-top:4px;}
.phs-bubble a{color:inherit;text-decoration:underline;}
@media (max-width:520px){ .phs-bubble{max-width:88%;} }
</style>
<?php
echo '<body class="phs-chat-view"><div class="phs-chat-wrap">';
printf('<div class="phs-chat-title">Chat CID %s</div>', esc_html($lead['cid']));
echo '<div class="phs-chat">';
if (!empty($lead['messages']) && is_array($lead['messages'])){
    foreach ($lead['messages'] as $m){
        $role = (($m['role']??'user')==='user') ? 'user' : 'agent';
        $txt  = isset($m['text']) ? $m['text'] : '';
        echo '<div class="phs-msg '.$role.'"><div class="phs-bubble">'.esc_html($txt).'</div></div>';
    }
} else {
    echo '<div class="phs-msg agent"><div class="phs-bubble">Sin mensajes.</div></div>';
}
echo '</div></div></body>';
exit;

    }
});

/** ================ Hook desde el chat (cada intercambio) ================ */
function phsbot_leads_on_exchange($cid, $user_text, $assistant_text, $meta=array()){
    if (!$cid) return;

    $lead = phsbot_leads_get($cid);
    $now  = current_time('mysql');

    if (!$lead) {
        $lead = array(
            'cid' => $cid,
            'first_seen' => $now,
            'last_seen'  => $now,
            'score'      => 0,
            'rationale'  => '',
            'email'      => null,
            'phone'      => null,
            'name'       => null,
            'messages'   => array(),
            'notified'   => array('telegram'=>0,'email_instant'=>0,'email_final'=>0),
            'telegram_msg_id' => 0,
            'summary'         => '',
            'summary_updated' => 0,
            'view_token'      => '',
            'closed'          => 0,
            'page'            => '',
            'last_change_ts'  => time(),
        );
    } else {
        $lead['last_seen'] = $now;
    }

    // Origen de página si viene
    if (!empty($meta['page'])) $lead['page'] = esc_url_raw($meta['page']);
    if (empty($lead['page']) && !empty($meta['url'])) $lead['page'] = esc_url_raw($meta['url']);

    // Mensajes
    if (is_string($user_text) && $user_text !== '') {
        $lead['messages'][] = array('t'=>time(),'role'=>'user','text'=>wp_strip_all_tags($user_text));
    }
    if (is_string($assistant_text) && $assistant_text !== '') {
        $lead['messages'][] = array('t'=>time(),'role'=>'assistant','text'=>wp_strip_all_tags($assistant_text));
    }

    // Extraer contactos del mensaje del usuario
    $email = phsbot_extract_email($user_text ?: '');
    $phone = phsbot_extract_phone($user_text ?: '');
    if ($email) $lead['email'] = $email;
    if ($phone) $lead['phone'] = $phone;

    // Nombre desde meta o desde el mensaje actual
    if (empty($lead['name'])) {
        if (!empty($meta['name'])) {
            $lead['name'] = sanitize_text_field($meta['name']);
        } else {
            $maybeName = phsbot_extract_name($user_text ?: '');
            if ($maybeName) $lead['name'] = $maybeName;
        }
    }
    // Si aún no hay nombre, backfill del histórico
    if (empty($lead['name'])) {
        $fromHistory = phsbot_leads_backfill_name($lead['messages']);
        if ($fromHistory) $lead['name'] = $fromHistory;
    }

    // Re-evaluar score con LLM (compat)
    $cfg = phsbot_leads_get_settings();
    if (!empty($cfg['reevaluate_each_message'])) {
        $sc = phsbot_leads_score_with_llm($lead);
        $lead['score'] = intval(max(0, min(10, $sc['score'] ?? 0)));
        $lead['rationale'] = (string)($sc['rationale'] ?? '');
    }

    // Resumen IA (caché 120s)
    $lead['summary'] = phsbot_leads_summarize_chat($lead);
    $lead['summary_updated'] = time();

    // Enlace público
    $view_link = phsbot_leads_get_view_link($lead);

    // Config de notificaciones
    $notify_to = (string)($cfg['daily_summary_email'] ?: phsbot_setting('notify_email',''));
    $tg_token  = (string)($cfg['telegram_token_override'] ?: phsbot_setting('telegram_token',''));
    $tg_chat   = (string)($cfg['telegram_chat_id_override'] ?: phsbot_setting('telegram_chat_id',''));
    // Fallbacks extra
    if (!$tg_token) $tg_token = (string) phsbot_setting('telegram_bot_token','');
    if (!$tg_chat)  $tg_chat  = (string) phsbot_setting('telegram_channel_id','');
    if (defined('PHSBOT_TELEGRAM_TOKEN') && !$tg_token) $tg_token = (string) PHSBOT_TELEGRAM_TOKEN;
    if (defined('PHSBOT_TELEGRAM_CHAT')  && !$tg_chat)  $tg_chat  = (string) PHSBOT_TELEGRAM_CHAT;

    // Reglas NUEVAS:
    // 1) Si hay teléfono → Telegram inmediato
    // 2) Si solo email y score >= 8 → Telegram inmediato
    $must_send_tg_immediate = false;
    if (!empty($lead['phone'])) {
        $must_send_tg_immediate = true;
    } elseif (!empty($lead['email']) && empty($lead['phone']) && intval($lead['score'])>=8) {
        $must_send_tg_immediate = true;
    }

    // Mensajes comunes
    $fecha  = current_time('d/m/Y H:i');
    $page   = !empty($lead['page']) ? $lead['page'] : home_url('/');
    $nombre = !empty($lead['name']) ? $lead['name'] : '—';
    $tel    = !empty($lead['phone']) ? $lead['phone'] : '—';
    $mail   = !empty($lead['email']) ? $lead['email'] : '—';

    $title_line = "🔥 <b>NUEVO LEAD: </b> " . ($tel !== '—' ? esc_html($tel) : esc_html($mail)) . "   (score: " . intval($lead['score']) . ") :";
    $body_lines = array(
        "<b>Mail:</b> " . esc_html($mail),
        "<b>Nombre:</b> " . esc_html($nombre),
        "<b>Teléfono:</b> " . esc_html($tel),
        "<b>Chat:</b> " . esc_html($lead['summary']),
        "<b>Página:</b> " . esc_url($page),
        "<b>Fecha:</b> " . esc_html($fecha),
        '',
        '<a href="'.esc_url($view_link).'">👉 Ver todo el chat</a>',
    );
    $tg_message   = $title_line . "\n" . implode("\n", $body_lines);
    $mail_message = $title_line . "<br>" . implode("<br>", $body_lines);

    // Telegram inmediato + edición si cambia
    if ($must_send_tg_immediate && $tg_token && $tg_chat) {
        if (!empty($lead['telegram_msg_id'])) {
            phsbot_telegram_edit($tg_token, $tg_chat, intval($lead['telegram_msg_id']), $tg_message);
        } else {
            $mid = phsbot_telegram_send($tg_token, $tg_chat, $tg_message);
            if ($mid) $lead['telegram_msg_id'] = $mid;
        }
        $lead['notified']['telegram'] = intval($lead['score']); // compat UI
    } elseif (!empty($lead['telegram_msg_id']) && $tg_token && $tg_chat) {
        phsbot_telegram_edit($tg_token, $tg_chat, intval($lead['telegram_msg_id']), $tg_message);
    }

    // Email final se envía en cron de inactividad (no aquí)

    $lead['last_change_ts'] = time();
    phsbot_leads_put($cid, $lead);
}

/** ================ Resumen diario (legacy) ================ */
function phsbot_leads_cron_hook(){
    $cfg = phsbot_leads_get_settings();
    $to  = (string)($cfg['daily_summary_email'] ?: phsbot_setting('notify_email',''));
    $min = intval($cfg['email_daily_threshold']);
    if (!$to) return;

    $all = phsbot_leads_all();
    if (!$all) return;

    $lines = array();
    foreach ($all as $lead){
        if (intval($lead['score']) >= $min) {
            $lines[] = sprintf(
                "- [%s] score %d | email %s | tel %s",
                $lead['last_seen'],
                intval($lead['score']),
                $lead['email']?:'—',
                $lead['phone']?:'—'
            );
        }
    }
    if ($lines){
        $body = "Resumen diario de leads >= {$min}\n\n".implode("\n", $lines);
        phsbot_notify_email($to, "Resumen diario de Leads (>= {$min})", nl2br(esc_html($body)));
    }
}
add_action('phsbot_leads_daily_digest','phsbot_leads_cron_hook');
function phsbot_leads_schedule_cron(){
    if (!wp_next_scheduled('phsbot_leads_daily_digest')) {
        wp_schedule_event(time()+3600, 'daily', 'phsbot_leads_daily_digest');
    }
}
function phsbot_leads_unschedule_cron(){
    $ts = wp_next_scheduled('phsbot_leads_daily_digest');
    if ($ts) wp_unschedule_event($ts, 'phsbot_leads_daily_digest');
}
add_action('plugins_loaded', 'phsbot_leads_schedule_cron');

/** ================ Cron: cierre por inactividad (10 min) ================ */
add_filter('cron_schedules', function($s){
    $s['phsbot_every_two_minutes'] = array('interval' => 120, 'display'=>'Cada 2 minutos');
    return $s;
});
add_action('plugins_loaded', function(){
    if (!wp_next_scheduled('phsbot_leads_inactive_check')) {
        wp_schedule_event(time()+180, 'phsbot_every_two_minutes', 'phsbot_leads_inactive_check');
    }
});
add_action('phsbot_leads_inactive_check', function(){
    $INACT_MIN = 10;
    $now_ts = time();
    $all = phsbot_leads_all();
    $changed = false;

    $cfg       = phsbot_leads_get_settings();
    $notify_to = (string)($cfg['daily_summary_email'] ?: phsbot_setting('notify_email',''));

    foreach ($all as $cid => $lead){
        if (!empty($lead['closed'])) continue;

        $last_seen_ts = strtotime($lead['last_seen'] ?? 'now');
        if ($now_ts - $last_seen_ts < ($INACT_MIN * 60)) continue;

        // Final de conversación
        $fecha  = date_i18n('d/m/Y H:i', $now_ts);
        $page   = !empty($lead['page']) ? $lead['page'] : home_url('/');
        $nombre = !empty($lead['name']) ? $lead['name'] : '—';
        $tel    = !empty($lead['phone']) ? $lead['phone'] : '—';
        $mail   = !empty($lead['email']) ? $lead['email'] : '—';

        // Sin contacto => borrar
        if (empty($lead['email']) && empty($lead['phone'])) {
            unset($all[$cid]);
            $changed = true;
            continue;
        }

        // Email SI o SI si hay email (una vez)
        if (!empty($lead['email']) && empty($lead['notified']['email_final'])) {
            $summary = phsbot_leads_summarize_chat($lead);
            $view_link = phsbot_leads_get_view_link($lead);
            $title_line  = "🔥 <b>NUEVO LEAD: </b> " . ($tel !== '—' ? esc_html($tel) : esc_html($mail)) . "   (score: " . intval($lead['score']) . ") :";
            $body_lines = array(
                "<b>Mail:</b> " . esc_html($mail),
                "<b>Nombre:</b> " . esc_html($nombre),
                "<b>Teléfono:</b> " . esc_html($tel),
                "<b>Chat:</b> " . esc_html($summary),
                "<b>Página:</b> " . esc_url($page),
                "<b>Fecha:</b> " . esc_html($fecha),
                '',
                '<a href="'.esc_url($view_link).'">👉 Ver todo el chat</a>',
            );
            phsbot_notify_email($notify_to, 'NUEVO LEAD', $title_line . '<br>' . implode('<br>', $body_lines));
            $lead['notified']['email_final'] = 1;
        }

        $lead['closed'] = 1;
        $all[$cid] = $lead;
        $changed = true;
    }

    if ($changed) phsbot_leads_put_all($all);
});

/** ================ Admin UI (submenu bajo menú principal del plugin) ================ */
add_action('admin_init', function(){
    register_setting(PHSBOT_LEADS_GROUP, PHSBOT_LEADS_OPT, array(
        'type'=>'array',
        'sanitize_callback' => function($in){
            $d = phsbot_leads_defaults();
            $out = $d;
            $out['scoring_prompt'] = wp_kses_post($in['scoring_prompt'] ?? $d['scoring_prompt']);
            $out['telegram_threshold']      = max(0,min(10,intval($in['telegram_threshold'] ?? $d['telegram_threshold'])));
            $out['email_instant_threshold'] = max(0,min(10,intval($in['email_instant_threshold'] ?? $d['email_instant_threshold'])));
            $out['email_daily_threshold']   = max(0,min(10,intval($in['email_daily_threshold'] ?? $d['email_daily_threshold'])));
            $out['reevaluate_each_message'] = !empty($in['reevaluate_each_message']) ? 1 : 0;
            $out['escalate_on_upgrade']     = !empty($in['escalate_on_upgrade']) ? 1 : 0;
            $out['daily_summary_email']     = sanitize_email($in['daily_summary_email'] ?? $d['daily_summary_email']);
            $out['telegram_token_override'] = sanitize_text_field($in['telegram_token_override'] ?? $d['telegram_token_override']);
            $out['telegram_chat_id_override'] = sanitize_text_field($in['telegram_chat_id_override'] ?? $d['telegram_chat_id_override']);
            return $out;
        }
    ));
});

add_action('admin_menu', function(){
    $parent_slug = defined('PHSBOT_MENU_SLUG') ? PHSBOT_MENU_SLUG : 'phsbot';
    $has_parent = false;
    global $menu;
    if (is_array($menu)) {
        foreach ($menu as $m) {
            if (!empty($m[2]) && $m[2]===$parent_slug) { $has_parent = true; break; }
        }
    }
    if ($has_parent) {
        add_submenu_page($parent_slug, 'Leads', 'Leads', 'manage_options', 'phsbot-leads', 'phsbot_leads_admin_page');
    } else {
        
    }
});

/** ================ Admin Page ================ */
function phsbot_leads_admin_page(){
    if (!current_user_can('manage_options')) return;

    // Acciones POST: borrar masivo / borrar uno / vaciar memoria / purgar / reset navegador
    if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['phsbot_leads_action'])) {
        check_admin_referer('phsbot_leads_nonce');
        $action = sanitize_text_field($_POST['phsbot_leads_action']);

        if ($action==='delete_many') {
            $ids = array_map('sanitize_text_field', $_POST['lead_ids'] ?? array());
            if ($ids) phsbot_leads_delete_many($ids);
            echo '<div class="updated"><p>Leads eliminados.</p></div>';

        } elseif ($action==='delete_one') {
            $cid = sanitize_text_field($_POST['cid'] ?? '');
            if ($cid) phsbot_leads_delete_many(array($cid));
            echo '<div class="updated"><p>Lead eliminado.</p></div>';

        } elseif ($action==='clear_memory') {
            phsbot_leads_clear_all();
            phsbot_client_bump_reset(); // también resetea navegadores
            echo '<div class="updated"><p>Memoria de leads vaciada y chat reiniciado en navegadores.</p></div>';

        } elseif ($action==='purge_closed_30') {
            phsbot_leads_purge_closed_before(30);
            echo '<div class="updated"><p>Leads cerrados de &gt;30 días eliminados.</p></div>';

        } elseif ($action==='bump_client_reset') {
            phsbot_client_bump_reset();
            echo '<div class="updated"><p>Se ha forzado el reinicio del chat en navegadores.</p></div>';
        }
    }

    $cfg = phsbot_leads_get_settings();

    // Filtros de listado
    $order   = isset($_GET['order']) ? sanitize_text_field($_GET['order']) : 'desc';
    $minScore = isset($_GET['minscore']) ? intval($_GET['minscore']) : 0;

    $all = phsbot_leads_all();
    $leads = array_values($all);

    // Ordenar por last_seen
    usort($leads, function($a,$b) use($order){
        $va = isset($a['last_seen']) ? strtotime($a['last_seen']) : 0;
        $vb = isset($b['last_seen']) ? strtotime($b['last_seen']) : 0;
        if ($va == $vb) return 0;
        return ($order==='asc') ? ($va<$vb?-1:1) : ($va>$vb?-1:1);
    });

    // Filtrar por score mínimo
    if ($minScore>0) {
        $leads = array_filter($leads, function($L) use($minScore){
            return intval($L['score']) >= $minScore;
        });
    }

    // UI
    ?>
    <div class="wrap">
        <h1>Leads</h1>

        <form method="get" style="margin:12px 0;">
            <input type="hidden" name="page" value="phsbot-leads">
            <label>Orden:
                <select name="order">
                    <option value="desc" <?php selected($order,'desc'); ?>>Recientes primero</option>
                    <option value="asc"  <?php selected($order,'asc');  ?>>Antiguos primero</option>
                </select>
            </label>
            <label style="margin-left:10px;">Score mínimo:
                <input type="number" name="minscore" min="0" max="10" value="<?php echo esc_attr($minScore); ?>" style="width:64px">
            </label>
            <button class="button">Aplicar</button>
        </form>

        <div style="display:flex; gap:10px; align-items:center; margin:8px 0;">
            <!-- Reset chat (navegador) -->
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('phsbot_leads_nonce'); ?>
                <input type="hidden" name="phsbot_leads_action" value="bump_client_reset">
                <button class="button" onclick="return confirm('Esto forzará que los navegadores borren la memoria local del chat al recargar. ¿Continuar?')">
                    Reset chat (navegador)
                </button>
            </form>
            <!-- Purgar cerrados >30d -->
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('phsbot_leads_nonce'); ?>
                <input type="hidden" name="phsbot_leads_action" value="purge_closed_30">
                <button class="button" onclick="return confirm('¿Eliminar cerrados de &gt;30 días?')">Purgar cerrados &gt;30 días</button>
            </form>
            <!-- Vaciar memoria -->
            <form method="post" style="display:inline;">
                <?php wp_nonce_field('phsbot_leads_nonce'); ?>
                <input type="hidden" name="phsbot_leads_action" value="clear_memory">
                <button class="button" onclick="return confirm('¿Vaciar toda la memoria de leads y resetear chats?')">Vaciar memoria</button>
            </form>
        </div>

        <!-- FORM de borrado masivo + tabla (no anidar otros forms dentro) -->
        <form method="post" style="margin:10px 0;">
            <?php wp_nonce_field('phsbot_leads_nonce'); ?>
            <input type="hidden" name="phsbot_leads_action" value="delete_many">

            <div style="margin-bottom:8px;">
                <button class="button button-secondary" onclick="return confirm('¿Eliminar los leads seleccionados?')">Eliminar seleccionados</button>
            </div>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th style="width:36px"><input type="checkbox" onclick="document.querySelectorAll('.lead-check').forEach(c=>c.checked=this.checked)"></th>
                        <th>Nombre</th>
                        <th>Mail</th>
                        <th>Teléfono</th>
                        <th>Score</th>
                        <th>Fecha</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                <?php
                $need_persist = false;
                if (empty($leads)): ?>
                    <tr><td colspan="7">Sin leads todavía.</td></tr>
                <?php else:
                    foreach ($leads as $lead):
                        // Backfill de nombre en listado si falta (y persistimos)
                        if (empty($lead['name'])) {
                            $guess = phsbot_leads_backfill_name($lead['messages'] ?? array());
                            if ($guess) {
                                $lead['name'] = $guess;
                                $all[$lead['cid']] = $lead;
                                $need_persist = true;
                            }
                        }

                        $cid     = esc_html($lead['cid']);
                        $nombre  = !empty($lead['name'])  ? $lead['name']  : '—';
                        $mail    = !empty($lead['email']) ? $lead['email'] : '—';
                        $tel     = !empty($lead['phone']) ? $lead['phone'] : '—';
                        $score   = intval($lead['score']);
                        $fecha   = !empty($lead['last_seen']) ? $lead['last_seen'] : '—';
                        $page    = esc_url(!empty($lead['page']) ? $lead['page'] : home_url('/'));
                        $summary = !empty($lead['summary']) ? $lead['summary'] : '';
                        $view    = '';
                        if (!empty($lead['view_token'])) $view = add_query_arg(array('phsbot_view_chat'=>$lead['view_token']), home_url('/'));
                        $messages_json = esc_attr(wp_json_encode($lead['messages'] ?? array()));
                    ?>
                    <tr>
                        <td><input type="checkbox" class="lead-check" name="lead_ids[]" value="<?php echo $cid; ?>"></td>
                        <td><?php echo esc_html($nombre); ?></td>
                        <td><?php echo esc_html($mail); ?></td>
                        <td><?php echo esc_html($tel); ?></td>
                        <td><?php echo $score; ?></td>
                        <td><?php echo esc_html($fecha); ?></td>
                        <td>
                            <button type="button"
                                class="button view-chat"
                                data-cid="<?php echo $cid; ?>"
                                data-nombre="<?php echo esc_attr($nombre); ?>"
                                data-mail="<?php echo esc_attr($mail); ?>"
                                data-tel="<?php echo esc_attr($tel); ?>"
                                data-score="<?php echo esc_attr($score); ?>"
                                data-fecha="<?php echo esc_attr($fecha); ?>"
                                data-page="<?php echo $page; ?>"
                                data-link="<?php echo esc_url($view); ?>"
                                data-summary="<?php echo esc_attr($summary); ?>"
                                data-messages='<?php echo $messages_json; ?>'>Ver</button>

                            <form method="post" style="display:inline;">
                                <?php wp_nonce_field('phsbot_leads_nonce'); ?>
                                <input type="hidden" name="phsbot_leads_action" value="delete_one">
                                <input type="hidden" name="cid" value="<?php echo $cid; ?>">
                                <button class="button button-link-delete" onclick="return confirm('¿Eliminar este lead?')">Eliminar</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </form>

        <?php if (!empty($need_persist)) phsbot_leads_put_all($all); ?>

        <hr style="margin:24px 0;">

        <details>
            <summary style="font-size:1.1em; font-weight:600; cursor:pointer;">Configuración de scoring y avisos</summary>
            <div style="margin-top:12px;">
                <form method="post" action="options.php">
                    <?php settings_fields(PHSBOT_LEADS_GROUP); $s = phsbot_leads_get_settings(); ?>
                    <table class="form-table" role="presentation">
                        <tbody>
                            <tr>
                                <th scope="row">Umbrales (legacy)</th>
                                <td>
                                    <label>Telegram: <input type="number" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[telegram_threshold]" min="0" max="10" value="<?php echo esc_attr($s['telegram_threshold']); ?>" style="width:64px"></label>
                                    &nbsp;&nbsp;
                                    <label>Email instantáneo: <input type="number" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[email_instant_threshold]" min="0" max="10" value="<?php echo esc_attr($s['email_instant_threshold']); ?>" style="width:64px"></label>
                                    &nbsp;&nbsp;
                                    <label>Resumen diario (min score): <input type="number" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[email_daily_threshold]" min="0" max="10" value="<?php echo esc_attr($s['email_daily_threshold']); ?>" style="width:64px"></label>
                                    <p class="description">Los envíos inmediatos ahora siguen reglas: Teléfono ⇒ Telegram; Solo email + score ≥ 8 ⇒ Telegram; Email ⇒ correo al finalizar conversación.</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Re-evaluación</th>
                                <td>
                                    <label><input type="checkbox" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[reevaluate_each_message]" value="1" <?php checked($s['reevaluate_each_message'],1); ?>> Re-evaluar score en cada mensaje</label><br>
                                    <label><input type="checkbox" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[escalate_on_upgrade]" value="1" <?php checked($s['escalate_on_upgrade'],1); ?>> Escalar avisos si sube de tramo (legacy)</label>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Email destino</th>
                                <td>
                                    <input type="email" class="regular-text" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[daily_summary_email]" value="<?php echo esc_attr($s['daily_summary_email']); ?>">
                                    <p class="description">Si vacío, usa el email global (notify_email).</p>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Telegram (override opcional)</th>
                                <td>
                                    <label>Bot token: <input type="text" class="regular-text" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[telegram_token_override]" value="<?php echo esc_attr($s['telegram_token_override']); ?>"></label><br>
                                    <label>Chat ID: <input type="text" class="regular-text" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[telegram_chat_id_override]" value="<?php echo esc_attr($s['telegram_chat_id_override']); ?>"></label>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">Prompt de scoring</th>
                                <td>
                                    <textarea class="large-text code" rows="8" name="<?php echo esc_attr(PHSBOT_LEADS_OPT); ?>[scoring_prompt]"><?php echo esc_textarea($s['scoring_prompt']); ?></textarea>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <?php submit_button('Guardar configuración de Leads'); ?>
                </form>
            </div>
        </details>
    </div>

    <!-- Modal -->
    <div id="phsbot-lead-modal" style="display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:100000;">
        <div style="position:absolute; left:50%; top:50%; transform:translate(-50%,-50%); width:min(900px,90vw); max-height:85vh; background:#fff; border-radius:8px; box-shadow:0 10px 40px rgba(0,0,0,.25); overflow:hidden;">
            <div style="padding:12px 16px; border-bottom:1px solid #e5e5e5; display:flex; align-items:center; justify-content:space-between;">
                <strong id="phsbot-lead-modal-title">Detalle del lead</strong>
                <button type="button" class="button" onclick="document.getElementById('phsbot-lead-modal').style.display='none'">Cerrar</button>
            </div>
            <div id="phsbot-lead-modal-body" style="padding:16px; overflow:auto; max-height:calc(85vh - 60px);">
                <!-- contenido dinámico -->
            </div>
        </div>
    </div>
    <script>
    (function(){
        function el(tag, attrs, html){
            var n = document.createElement(tag);
            if (attrs) Object.keys(attrs).forEach(function(k){ n.setAttribute(k, attrs[k]); });
            if (html!=null) n.innerHTML = html;
            return n;
        }
        function renderMessages(msgs){
            var wrap = el('div', {style:'display:flex; flex-direction:column; gap:8px;'});
            msgs.forEach(function(m){
                var role = m.role==='user' ? 'Cliente' : 'Agente';
                var box  = el('div', {style:'padding:8px 10px; background:#f7f7f7; border:1px solid #eee; border-radius:6px;'});
                box.appendChild(el('div', {style:'font-weight:600; margin-bottom:4px;'}, role));
                box.appendChild(el('div', {}, (m.text||'').toString()));
                wrap.appendChild(box);
            });
            return wrap;
        }

        document.querySelectorAll('.view-chat').forEach(function(btn){
            btn.addEventListener('click', function(){
                var cid    = btn.getAttribute('data-cid');
                var nombre = btn.getAttribute('data-nombre');
                var mail   = btn.getAttribute('data-mail');
                var tel    = btn.getAttribute('data-tel');
                var score  = btn.getAttribute('data-score');
                var fecha  = btn.getAttribute('data-fecha');
                var page   = btn.getAttribute('data-page');
                var link   = btn.getAttribute('data-link');
                var summary= btn.getAttribute('data-summary') || '';
                var msgs   = [];
                try { msgs = JSON.parse(btn.getAttribute('data-messages')||'[]'); } catch(e){ msgs=[]; }

                var title = document.getElementById('phsbot-lead-modal-title');
                var body  = document.getElementById('phsbot-lead-modal-body');
                title.textContent = 'Lead ('+fecha+')';
                body.innerHTML = '';

                var meta = el('div', {style:'margin-bottom:12px;'});
                meta.innerHTML = '<div><b>Nombre:</b> '+(nombre||'—')+'</div>'
                               + '<div><b>Mail:</b> '+(mail||'—')+'</div>'
                               + '<div><b>Teléfono:</b> '+(tel||'—')+'</div>'
                               + '<div><b>Score:</b> '+(score||'—')+'</div>'
                               + '<div><b>Página:</b> <a href="'+page+'" target="_blank" rel="noopener">'+page+'</a></div>'
                               + (link?('<div><a href="'+link+'" target="_blank" rel="noopener">Ver chat público</a></div>'):'');
                body.appendChild(meta);

                if (summary){
                    var sum = el('div', {style:'margin:8px 0; padding:10px; background:#fff7e6; border:1px solid #ffe2a8; border-radius:6px;'});
                    sum.innerHTML = '<b>Resumen IA:</b> '+summary;
                    body.appendChild(sum);
                }

                var h2 = el('h3', {style:'margin:16px 0 8px 0;'}, 'Conversación');
                body.appendChild(h2);
                body.appendChild(renderMessages(msgs));

                document.getElementById('phsbot-lead-modal').style.display = 'block';
            });
        });

        // Cerrar modal con ESC o click fuera
        document.addEventListener('keydown', function(e){
            if (e.key==='Escape') document.getElementById('phsbot-lead-modal').style.display='none';
        });
        document.getElementById('phsbot-lead-modal').addEventListener('click', function(e){
            if (e.target.id==='phsbot-lead-modal') e.currentTarget.style.display='none';
        });
    })();
    </script>
    <?php
}