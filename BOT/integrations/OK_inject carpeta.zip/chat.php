<?php
// File: chat.php
if (!defined('ABSPATH')) exit;

// === Load mobile patch only on mobile (frontend) ===
add_action('init', function () {
    if (is_admin()) return;
    if (function_exists('wp_is_mobile') && !wp_is_mobile()) return;
    $patch = __DIR__ . '/mobile-patch.php';
    if (file_exists($patch)) require_once $patch;
}, 5);


/** =========================================================
 *  Constantes y helpers
 *  ======================================================= */
if (!defined('PHSBOT_CHAT_OPT'))   define('PHSBOT_CHAT_OPT',   'phsbot_chat_settings');
if (!defined('PHSBOT_CHAT_GROUP')) define('PHSBOT_CHAT_GROUP', 'phsbot_chat_group');
if (!defined('PHSBOT_KB_DOC_OPT')) define('PHSBOT_KB_DOC_OPT', 'phsbot_kb_document');

if (!function_exists('phsbot_setting')) {
    function phsbot_setting($key, $default = '') {
        $opt = get_option('phsbot_settings', array());
        return isset($opt[$key]) ? $opt[$key] : $default;
    }
}

/** =========================================================
 *  Defaults del chat
 *  ======================================================= */
function phsbot_chat_defaults() {
    return array(
        'model'            => 'gpt-4o-mini',
        'temperature'      => 0.3,
        'tone'             => 'profesional, cercano y claro',
        'prompt_extra'     => '',
        'welcome'          => 'Hola 👋 Soy Ángela ¿Me dices tu nombre?',
        'allow_html'       => 1,
        'allow_elementor'  => 1,
        'allow_live_fetch' => 1,
        'max_history'      => 10,     // pares (user+assistant)
        'max_tokens'       => 1400,
        'max_height_vh'    => 70,
        'anchor_paragraph' => 1,      // ancla inicio del párrafo del bot
    );
}
function phsbot_chat_get_settings() {
    $cur = get_option(PHSBOT_CHAT_OPT, array());
    if (!is_array($cur)) $cur = array();
    return wp_parse_args($cur, phsbot_chat_defaults());
}

// === Labels mínimos del UI por idioma (sin WPML) ===
if (!function_exists('phsbot_ui_min')) {
    function phsbot_ui_min() {
        $label = function_exists('phs_detect_current_url_language')
            ? phs_detect_current_url_language()  // "Espanol", "Ingles", "Frances", ...
            : 'Espanol';
        $lang = strtolower($label);
        $map = array(
            'espanol'   => array('send' => 'Enviar',    'ph' => 'Escribe tu pregunta...',          'typing'=>'Escribiendo…'),
            'ingles'    => array('send' => 'Send',      'ph' => 'Type your question...',           'typing'=>'Typing…'),
            'frances'   => array('send' => 'Envoyer',   'ph' => 'Écrivez votre question...',       'typing'=>'Saisie…'),
            'aleman'    => array('send' => 'Senden',    'ph' => 'Schreibe deine Frage...',         'typing'=>'Tippen…'),
            'italiano'  => array('send' => 'Invia',     'ph' => 'Scrivi la tua domanda...',        'typing'=>'Sta scrivendo…'),
            'portugues' => array('send' => 'Enviar',    'ph' => 'Escreva sua pergunta...',         'typing'=>'Digitando…'),
            'holandes'  => array('send' => 'Verzenden', 'ph' => 'Typ je vraag...',                  'typing'=>'Typen…'),
        );
        if (!isset($map[$lang])) {
            $nav = isset($_SERVER['HTTP_ACCEPT_LANGUAGE']) ? substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2) : 'es';
            $lang = match($nav){
                'en'=>'ingles','fr'=>'frances','de'=>'aleman','it'=>'italiano','pt'=>'portugues','nl'=>'holandes',
                default=>'espanol'
            };
        }
        return $map[$lang];
    }
}

/** =========================================================
 *  I18N helpers para el modelo
 *  ======================================================= */
if (!function_exists('phs_lang_label')) {
    function phs_lang_label() {
        return function_exists('phs_detect_current_url_language')
            ? phs_detect_current_url_language()   // "Espanol", "Ingles", "Frances", ...
            : 'Espanol';
    }
}
if (!function_exists('phs_lang_prompt_word')) {
    function phs_lang_prompt_word($label = null) {
        $label = $label ?: phs_lang_label();
        $map = array(
            'Espanol'  => 'español',
            'Ingles'   => 'inglés',
            'Frances'  => 'francés',
            'Aleman'   => 'alemán',
            'Italiano' => 'italiano',
            'Portugues'=> 'portugués',
            'Holandes' => 'neerlandés',
        );
        return $map[$label] ?? 'español';
    }
}

/**
 * Traduce con OpenAI el saludo configurado al idioma de la URL/página.
 * - Cachea por 24h (transient) para evitar costes/latencia.
 * - Si falta API key o falla la llamada, devuelve el original.
 */
if (!function_exists('phsbot_translate_welcome_for_page')) {
    function phsbot_translate_welcome_for_page($welcome_text) {
        $welcome_text = (string)$welcome_text;
        $target_label = phs_lang_label(); // "Espanol", "Ingles", ...
        if ($target_label === 'Espanol' || $welcome_text === '') {
            return $welcome_text;
        }
        $cache_key = 'phsbot_welcome_i18n_' . md5($welcome_text . '|' . $target_label);
        $cached = get_transient($cache_key);
        if ($cached) return $cached;

        $api_key = (string) phsbot_setting('openai_api_key', '');
        if (!$api_key) return $welcome_text;

        $chat_settings = function_exists('phsbot_chat_get_settings') ? phsbot_chat_get_settings() : array();
        $model = !empty($chat_settings['model']) ? $chat_settings['model'] : 'gpt-4o-mini';

        $target_word = phs_lang_prompt_word($target_label); // "inglés", "francés", ...
        $system = "Eres un traductor profesional. Traduce exactamente el siguiente mensaje breve de bienvenida al {$target_word}. ".
                  "Conserva tono, emojis y tratamiento (tú/usted). Devuelve SOLO el texto traducido, sin comillas ni notas.";

        $res = wp_remote_post('https://api.openai.com/v1/chat/completions', array(
            'timeout' => 15,
            'headers' => array(
                'Authorization' => 'Bearer '.$api_key,
                'Content-Type'  => 'application/json',
            ),
            'body' => wp_json_encode(array(
                'model'       => $model,
                'messages'    => array(
                    array('role'=>'system', 'content'=>$system),
                    array('role'=>'user',   'content'=>$welcome_text),
                ),
                'temperature' => 0.2,
                'max_tokens'  => 120,
            )),
        ));

        if (!is_wp_error($res) && wp_remote_retrieve_response_code($res) === 200) {
            $body = json_decode(wp_remote_retrieve_body($res), true);
            $out  = trim($body['choices'][0]['message']['content'] ?? '');
            if ($out !== '') {
                set_transient($cache_key, $out, DAY_IN_SECONDS);
                return $out;
            }
        }
        return $welcome_text;
    }
}

/** =========================================================
 *  Admin: Submenú y ajustes (render llamado desde menu.php)
 *  ======================================================= */
add_action('admin_init', function(){
    register_setting(PHSBOT_CHAT_GROUP, PHSBOT_CHAT_OPT, array(
        'type' => 'array',
        'sanitize_callback' => function($in){
            $d = phsbot_chat_defaults();
            $out = $d;

            $out['model']            = sanitize_text_field($in['model'] ?? $d['model']);
            $out['temperature']      = min(1.0, max(0.0, floatval($in['temperature'] ?? $d['temperature'])));
            $out['tone']             = sanitize_text_field($in['tone'] ?? $d['tone']);
            $out['prompt_extra']     = wp_kses_post($in['prompt_extra'] ?? $d['prompt_extra']);
            $out['welcome']          = wp_kses_post($in['welcome'] ?? $d['welcome']);
            $out['allow_html']       = !empty($in['allow_html']) ? 1 : 0;
            $out['allow_elementor']  = !empty($in['allow_elementor']) ? 1 : 0;
            $out['allow_live_fetch'] = !empty($in['allow_live_fetch']) ? 1 : 0;
            $out['max_history']      = max(2, min(20, intval($in['max_history'] ?? $d['max_history'])));
            $out['max_tokens']       = max(400, min(7000, intval($in['max_tokens'] ?? $d['max_tokens'])));
            $out['max_height_vh']    = max(50, min(95, intval($in['max_height_vh'] ?? $d['max_height_vh'])));
            $out['anchor_paragraph'] = !empty($in['anchor_paragraph']) ? 1 : 0;

            return $out;
        },
        'default' => phsbot_chat_defaults(),
    ));
});

if (!function_exists('phsbot_render_chat_settings')) {
function phsbot_render_chat_settings(){
    if (!current_user_can(PHSBOT_CAP_SETTINGS)) {
        wp_die(__('No tienes permisos para acceder a esta página.', 'phsbot'), 403);
    }
    $s = phsbot_chat_get_settings();
    ?>
    <div class="wrap">
        <h1>PhsBot — Chat & Widget</h1>
        <form method="post" action="options.php">
            <?php settings_fields(PHSBOT_CHAT_GROUP); ?>
            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row">Modelo</th>
                        <td>
                            <select name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[model]">
                                <?php foreach (array('gpt-4o-mini','gpt-4o','gpt-4.1-mini') as $m): ?>
                                    <option value="<?php echo esc_attr($m); ?>" <?php selected($s['model'],$m); ?>><?php echo esc_html($m); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">Usa la OpenAI API Key configurada en <em>Configuración</em>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Temperatura</th>
                        <td><input type="number" step="0.1" min="0" max="1" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[temperature]" value="<?php echo esc_attr($s['temperature']); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Tono</th>
                        <td><input class="regular-text" type="text" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[tone]" value="<?php echo esc_attr($s['tone']); ?>" /></td>
                    </tr>
                    <tr>
                        <th scope="row">Prompt adicional</th>
                        <td>
                            <textarea class="large-text code" rows="6" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[prompt_extra]"><?php echo esc_textarea($s['prompt_extra']); ?></textarea>
                            <p class="description">Se concatena a las instrucciones base con la KB.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Mensaje de bienvenida</th>
                        <td><textarea class="large-text" rows="3" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[welcome]"><?php echo esc_textarea($s['welcome']); ?></textarea></td>
                    </tr>
                    <tr>
                        <th scope="row">Permisos de render</th>
                        <td>
                            <label><input type="checkbox" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[allow_html]" value="1" <?php checked($s['allow_html'],1); ?>> Permitir HTML</label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[allow_elementor]" value="1" <?php checked($s['allow_elementor'],1); ?>> Permitir shortcodes de Elementor</label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[allow_live_fetch]" value="1" <?php checked($s['allow_live_fetch'],1); ?>> Permitir consulta rápida de la URL actual</label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Límites</th>
                        <td>
                            <label>Historial máx.: <input type="number" min="2" max="20" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[max_history]" value="<?php echo esc_attr($s['max_history']); ?>"></label>
                            &nbsp; &nbsp;
                            <label>Max tokens: <input type="number" min="400" max="7000" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[max_tokens]" value="<?php echo esc_attr($s['max_tokens']); ?>"></label>
                            &nbsp; &nbsp;
                            <label>Altura máxima: <input type="number" min="50" max="95" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[max_height_vh]" value="<?php echo esc_attr($s['max_height_vh']); ?>"> vh</label><br>
                            <label><input type="checkbox" name="<?php echo esc_attr(PHSBOT_CHAT_OPT); ?>[anchor_paragraph]" value="1" <?php checked($s['anchor_paragraph'],1); ?>> Anclar el inicio de cada respuesta a la vista</label>
                        </td>
                    </tr>
                </tbody>
            </table>
            <?php submit_button('Guardar ajustes'); ?>
        </form>
    </div>
    <?php
}}

/** =========================================================
 *  Front: Markup + CSS + JS (memoria persistente)
 *  ======================================================= */
if (!function_exists('phsbot_render_chat_markup')) {
function phsbot_render_chat_markup($mode = 'floating') {
    static $did_assets = false;

    // Settings globales (phsbot.php)
    $pos   = (string) phsbot_setting('chat_position', 'bottom-right');
    $w     = (string) phsbot_setting('chat_width', '360px');
    $h     = (string) phsbot_setting('chat_height','520px');

    $cpri  = (string) phsbot_setting('color_primary', '#7A1C1C');
    $csec  = (string) phsbot_setting('color_secondary', '#C4A484');
    $cbg   = (string) phsbot_setting('color_background', '#FFFFFF');
    $ctxt  = (string) phsbot_setting('color_text', '#1A1A1A');
    $cbot  = (string) phsbot_setting('color_bot_bubble', '#F3F3F3');
    $cusr  = (string) phsbot_setting('color_user_bubble', '#EDE7E1');

    $chat  = phsbot_chat_get_settings();
    $maxvh = intval($chat['max_height_vh']);

    // Posición fija para flotante
    $is_left  = (strpos($pos,'left') !== false);
    $is_top   = (strpos($pos,'top')  !== false);
    $side_x   = $is_left ? 'left' : 'right';
    $side_y   = $is_top  ? 'top'  : 'bottom';

    // Assets (solo una vez)
    if (!$did_assets) {
        $did_assets = true;
        ?>
        <style id="phsbot-chat-css">
            :root{
                --phsbot-primary: <?php echo esc_html($cpri); ?>;
                --phsbot-secondary: <?php echo esc_html($csec); ?>;
                --phsbot-bg: <?php echo esc_html($cbg); ?>;
                --phsbot-text: <?php echo esc_html($ctxt); ?>;
                --phsbot-bot: <?php echo esc_html($cbot); ?>;
                --phsbot-user: <?php echo esc_html($cusr); ?>;
            }
            .phsbot-launcher{
                position: fixed; <?php echo $side_x; ?>:18px; <?php echo $side_y; ?>:18px;
                z-index: 100000;
                width: 90px; height: 90px; border-radius: 50%;
                background: var(--phsbot-primary);
                color: #fff; display:flex; align-items:center; justify-content:center;
                box-shadow: 0 10px 22px rgba(0,0,0,.2);
                cursor: pointer; user-select: none;
            }
            .phsbot-launcher svg{ width:198px; height:198px; fill:#fff; }
            .phsbot-wrap{
                position: fixed; <?php echo $side_x; ?>:18px; <?php echo $side_y; ?>:88px;
                z-index: 99999; width: <?php echo esc_html($w); ?>;
                max-width: min(92vw, 520px);
            }
            .phsbot-card{
                width: 100%;
                background: var(--phsbot-bg);
                color: var(--phsbot-text);
                border-radius: 14px;
                box-shadow: 0 18px 48px rgba(0,0,0,.22);
                overflow: hidden;
                display:none;
            }
            .phsbot-head{
                background: linear-gradient(180deg, var(--phsbot-primary), var(--phsbot-secondary));
                color:#fff; padding:10px 12px; font-weight:600; display:flex; align-items:center; justify-content:space-between; cursor:pointer;
            }
            .phsbot-head-title{ display:flex; align-items:center; gap:8px; }
            .phsbot-body{
                height: <?php echo esc_html($h); ?>;
                max-height: <?php echo intval($maxvh); ?>vh;
                overflow: auto;
                padding: 12px;
                padding-bottom: 60px; /* evita que se tape el typing con la caja de entrada */
                transition: height .2s ease;
            }
            .phsbot-msg{ margin: 10px 0; display:flex; gap:10px; }
            .phsbot-msg.bot .phsbot-bubble{ background: var(--phsbot-bot); }
            .phsbot-msg.user{ justify-content: flex-end; }
            .phsbot-msg.user .phsbot-bubble{ background: var(--phsbot-user); }
            .phsbot-bubble{
                border-radius: 10px; padding: 10px 12px; max-width: 88%;
                line-height: 1.45;
                overflow-wrap: anywhere;
            }
            .phsbot-input{
                display:flex; gap:8px; border-top:1px solid rgba(0,0,0,.08); padding:10px;
                background: #fff;
            }
            .phsbot-input textarea{
                width:100%; min-height:42px; max-height:140px; resize: vertical;
                border:1px solid rgba(0,0,0,.12); border-radius: 8px; padding:8px 10px;
                outline: none;
            }
            .phsbot-input textarea:focus-visible{
                outline: 2px solid var(--phsbot-secondary);
            }
            .phsbot-send{
                background: var(--phsbot-primary); color:#fff; border:0; border-radius:8px; padding:0 12px; min-width:56px; cursor:pointer;
            }

            /* --- ICONO DE TECLADO ANIMADO PARA TYPING --- */
            .phsbot-bubble.typing{ display:flex; align-items:center; gap:8px; color: rgba(0,0,0,.78); min-width:120px; }
            .phsbot-typing-kb{ display:inline-flex; line-height:0; }
            .phsbot-typing-kb svg{ width:48px; height:38px; display:block; }
            .phsbot-typing-kb .key{ fill:#c8c8c8; transform-origin:center; animation:phsKey 1.05s infinite ease-in-out; }
            .phsbot-typing-kb .k2{ animation-delay:.15s; }
            .phsbot-typing-kb .k3{ animation-delay:.30s; }
            @keyframes phsKey{
              0%,70% { transform:translateY(0);   fill:#c8c8c8; }
              35%    { transform:translateY(1.5px); fill:#8a8a8a; }
            }
            .phsbot-typing-label{ opacity:.85; font-size:13px; }

            /* Inline embedding */
            .phsbot-inline{ position: relative; width: 100%; max-width: <?php echo esc_html($w); ?>; }
            .phsbot-inline .phsbot-wrap{ position: relative; inset: auto; width: 100%; max-width: 100%; }
            .phsbot-inline .phsbot-launcher{ display:none; }
        </style>
<?php $U = phsbot_ui_min(); ?>

        <script id="phsbot-chat-js">
        (function(){
            const ajaxUrl = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";
            const nonce   = "<?php echo esc_js(wp_create_nonce('phsbot_chat')); ?>";
            const cfg = {
                allowHTML:  <?php echo $chat['allow_html'] ? 'true' : 'false'; ?>,
                allowElem:  <?php echo $chat['allow_elementor'] ? 'true' : 'false'; ?>,
                anchorTop:  <?php echo $chat['anchor_paragraph'] ? 'true' : 'false'; ?>,
                maxVH:      <?php echo intval($maxvh); ?>,
                initialH:   "<?php echo esc_js($h); ?>",
                welcome:    <?php echo wp_json_encode(phsbot_translate_welcome_for_page((string)$chat['welcome'])); ?>,
                maxHistory: <?php echo intval($chat['max_history']); ?>
            };

            // === Persistencia por sesión de usuario ===
            function cid(){
                try{
                    let id = localStorage.getItem('phsbot:cid');
                    if (!id){
                        id = 'cid-' + Math.random().toString(36).slice(2) + Date.now().toString(36);
                        localStorage.setItem('phsbot:cid', id);
                    }
                    return id;
                }catch(e){
                    return 'cid-fallback';
                }
            }
            const CID = cid();
            const STORE_CONV = 'phsbot:conv:'+CID;
            const STORE_UI   = 'phsbot:ui:'+CID;

            function loadConv(){ try{ return JSON.parse(localStorage.getItem(STORE_CONV)||'[]'); }catch(e){ return []; } }
            function saveConv(arr){ try{ localStorage.setItem(STORE_CONV, JSON.stringify(arr||[])); }catch(e){} }
            function loadUI(){ try{ return JSON.parse(localStorage.getItem(STORE_UI)||'{}'); }catch(e){ return {}; } }
            function saveUI(obj){ try{ localStorage.setItem(STORE_UI, JSON.stringify(obj||{})); }catch(e){} }

            function qs(s,ctx){ return (ctx||document).querySelector(s); }
            function el(tag, attrs={}, html=''){
                const n = document.createElement(tag);
                Object.entries(attrs||{}).forEach(([k,v])=> n.setAttribute(k,v));
                if (html!=='' && html!=null) n.innerHTML = html;
                return n;
            }

            function ensureWrap(mode){
                let wrap = qs('#phsbot-root');
                if (!wrap) {
                    wrap = el('div', {id:'phsbot-root', class:'phsbot-wrap'});
                    document.body.appendChild(wrap);
                }
                if (mode === 'inline') wrap.classList.add('phsbot-inline'); else wrap.classList.remove('phsbot-inline');
                return wrap;
            }

            function buildUI(mode){
                const wrap = ensureWrap(mode);

                // Launcher
                let launcher = qs('.phsbot-launcher');
                if (!launcher && mode !== 'inline') {
                    launcher = el('div', {class:'phsbot-launcher', 'aria-label':'Abrir chat', role:'button'});
                    
                    
                    
                    
                   launcher.innerHTML = `<svg viewBox="0 0 64 64" width="56" height="56" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img">
  <title>Chat</title>
  <defs>
    <filter id="ds" x="-40%" y="-40%" width="180%" height="180%">
      <feDropShadow dx="0" dy="2" stdDeviation="2" flood-color="rgba(0,0,0,.25)" />
    </filter>

    <!-- Verde caqui -->
    <linearGradient id="g-kaqui" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%"  stop-color="#667a3a"/>
      <stop offset="100%" stop-color="#4c5e27"/>
    </linearGradient>

    <!-- Verde WhatsApp -->
    <linearGradient id="g-whatsapp" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%"  stop-color="#2fe070"/>
      <stop offset="100%" stop-color="#128C7E"/>
    </linearGradient>

    <style>
      .bubble { filter:url(#ds); stroke: rgba(255,255,255,.35); stroke-width:1.25; }
      .dot { fill:#fff; opacity:.95; }
      .a,.b { transform-box: fill-box; transform-origin: center; }

      /* ===== Timeline 6s =====
         A: 0–0.5s in, 0.5–2.5s hold, 2.5–3s out
         B: 3–3.5s in, 3.5–5.5s hold, 5.5–6s out
      */
      .a { animation: pulseA 6s ease-in-out infinite; }
      .b { animation: pulseB 6s ease-in-out infinite; }

      @keyframes pulseA {
        0%      { transform: scale(1); }
        8.333%  { transform: scale(1.28); }  /* 0.5s */
        41.666% { transform: scale(1.28); }  /* 2.5s (pausa 2s) */
        50%     { transform: scale(1); }     /* 3s */
        100%    { transform: scale(1); }
      }
      @keyframes pulseB {
        0%     { transform: scale(1); }
        50%    { transform: scale(1); }      /* 3s */
        58.333%{ transform: scale(1.28); }   /* 3.5s */
        91.666%{ transform: scale(1.28); }   /* 5.5s (pausa 2s) */
        100%   { transform: scale(1); }      /* 6s */
      }

      /* Dots typing */
      .typing .d1,.typing .d2,.typing .d3{
        animation: blink 1s ease-in-out infinite;
        transform-origin: center;
      }
      .typing .d2{ animation-delay:.12s; }
      .typing .d3{ animation-delay:.24s; }
      @keyframes blink{
        0%,80%,100%{ opacity:.25; transform:translateY(0) }
        40%       { opacity:1;    transform:translateY(-0.8px) }
      }

      /* Alternancia (A visible 0–50%, B visible 50–100%) en ciclo de 6s */
      .typingA { animation: phaseA 6s linear infinite; }
      .typingB { animation: phaseB 6s linear infinite; }
      @keyframes phaseA {
        0%   { opacity:1 }
        49%  { opacity:1 }
        50%  { opacity:0 }
        100% { opacity:0 }
      }
      @keyframes phaseB {
        0%   { opacity:0 }
        50%  { opacity:0 }
        51%  { opacity:1 }
        100% { opacity:1 }
      }

      @media (prefers-reduced-motion: reduce){
        .a,.b,.typing .d1,.typing .d2,.typing .d3,.typingA,.typingB{ animation: none !important; }
      }
    </style>
  </defs>

  <!-- Burbuja IZQ (verde caqui) -->
  <g class="a">
    <path class="bubble" fill="url(#g-kaqui)"
      d="M22 14c-8.3 0-15 5.9-15 13.1 0 5.3 3.4 9.9 8.5 12.1l-2 6.9c-.2.8.7 1.4 1.4.9l6.7-4.5c.4 0 .9.1 1.4.1 8.3 0 15-5.9 15-13.1S30.3 14 22 14z"/>
    <g class="typing typingA">
      <circle class="dot d1" cx="17.3" cy="27.2" r="1.8"/>
      <circle class="dot d2" cx="22.0" cy="27.2" r="1.8"/>
      <circle class="dot d3" cx="26.7" cy="27.2" r="1.8"/>
    </g>
  </g>

  <!-- Burbuja DER (verde WhatsApp) -->
  <g class="b">
    <path class="bubble" fill="url(#g-whatsapp)"
      d="M42 20c8.0 0 14.5 5.5 14.5 12.3 0 4.8-3.0 9-7.6 11.1l1.7 6.1c.2.8-.6 1.4-1.3 1l-6.2-4.1c-.4 0-.8.1-1.1.1-8.0 0-14.5-5.5-14.5-12.3S34 20 42 20z"/>
    <g class="typing typingB">
      <circle class="dot d1" cx="37.8" cy="32.6" r="1.8"/>
      <circle class="dot d2" cx="42.0" cy="32.6" r="1.8"/>
      <circle class="dot d3" cx="46.2" cy="32.6" r="1.8"/>
    </g>
  </g>
</svg>

`;
                   
                   
                   
                   

                    document.body.appendChild(launcher);
                }

                // Card
                if (!wrap.querySelector('.phsbot-card')) {
                    wrap.innerHTML = `
                        <div class="phsbot-card" data-open="0">
                            <div class="phsbot-head" role="button" aria-label="Cerrar/abrir chat">
                                <div class="phsbot-head-title">PHS Assistant</div>
                                <div class="btncierre">
  <img src="<?php echo esc_url( plugins_url('img/250.png', __FILE__) ); ?>" width="38" height="38" alt="">
</div>

                            </div>
                            <div class="phsbot-body" id="phsbot-body"></div>
                            <div class="phsbot-input">
                                <textarea id="phsbot-q" placeholder="<?php echo esc_attr($U['ph']); ?>"></textarea>
                                <button class="phsbot-send" id="phsbot-send"><?php echo esc_html($U['send']); ?></button>
                            </div>
                        </div>
                    `;
                    const card = wrap.querySelector('.phsbot-card');
                    const body = qs('#phsbot-body', wrap);
                    const send = qs('#phsbot-send', wrap);
                    const ta   = qs('#phsbot-q', wrap);

                    function toggleCard(){
                        const open = card.getAttribute('data-open') === '1';
                        const ui = loadUI();
                        if (open){
                            card.setAttribute('data-open','0');
                            card.style.display='none';
                            if (launcher) launcher.style.display='flex';
                            ui.open = false; saveUI(ui);
                        } else {
                            card.setAttribute('data-open','1');
                            card.style.display='block';
                            if (launcher) launcher.style.display='none';
                            ta.focus();
                            ui.open = true; saveUI(ui);
                            autoGrowBody(body);
                            scrollToBottom(body);
                        }
                    }
                    qs('.phsbot-head', wrap).addEventListener('click', toggleCard);
                    if (launcher) launcher.addEventListener('click', toggleCard);
                    send.addEventListener('click', ()=> doAsk(ta, body));
                    ta.addEventListener('keydown', (e)=>{
                        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doAsk(ta, body); }
                    });

                    // Render bienvenida + historial persistente
                    restoreConversation(body);

                    // Estado UI persistente
                    const ui = loadUI();
                    if (ui.open){
                        card.setAttribute('data-open','1');
                        card.style.display='block';
                        if (launcher) launcher.style.display='none';
                        if (ui.heightPx) { body.style.height = ui.heightPx + 'px'; }
                        autoGrowBody(body);
                        scrollToBottom(body);
                    } else {
                        card.style.display='none';
                        if (launcher) launcher.style.display='flex';
                    }

                    // Observa cambios de tamaño y guarda
                    const ro = new ResizeObserver(()=>{
                        const ui2 = loadUI();
                        ui2.heightPx = body.clientHeight;
                        saveUI(ui2);
                    });
                    ro.observe(body);
                }
            }

            function autoGrowBody(body){
                body.style.height = cfg.initialH;
                const maxPx = Math.round(window.innerHeight * (cfg.maxVH/100));
                const need  = Math.min(body.scrollHeight + 2, maxPx);
                body.style.height = need + 'px';
                const ui = loadUI(); ui.heightPx = body.clientHeight; saveUI(ui);
            }
            function scrollToBottom(body){ body.scrollTop = body.scrollHeight; }

            function appendMsg(roleClass, htmlOrText, body, anchorStart){
                const row = el('div', {class:'phsbot-msg ' + (roleClass==='bot'?'bot':'user')});
                const bbl = el('div', {class:'phsbot-bubble'});
                bbl.innerHTML = htmlOrText;
                row.appendChild(bbl);
                body.appendChild(row);

                autoGrowBody(body);

                if (anchorStart && roleClass==='bot' && cfg.anchorTop) {
                    const top = row.offsetTop;
                    body.scrollTo({ top: top - 6, behavior: 'instant' });
                } else {
                    scrollToBottom(body);
                }
            }

            function escapeHTML(s){ const d=document.createElement('div'); d.textContent=s; return d.innerHTML; }

            function restoreConversation(body){
                const conv = loadConv();
                if (conv.length === 0) {
                    if (cfg.welcome) appendMsg('bot', escapeHTML(cfg.welcome), body, true);
                    return;
                }
                body.innerHTML = '';
                conv.forEach(m => {
                    const roleClass = (m.role === 'assistant') ? 'bot' : 'user';
                    const html = m.html ? m.html : escapeHTML(m.text||'');
                    appendMsg(roleClass, html, body, false);
                });
                scrollToBottom(body);
            }

            function buildHistoryForAPI(){
                const conv = loadConv();
                const msgs = [];
                conv.forEach(m=>{
                    const role = (m.role === 'assistant') ? 'assistant' : 'user';
                    const content = (m.text || (m.html ? stripTags(m.html) : '')) + '';
                    msgs.push({role, content});
                });
                const max = Math.max(2, cfg.maxHistory*2);
                return msgs.slice(-max);
            }
            function stripTags(html){
                const tmp = document.createElement('div');
                tmp.innerHTML = html;
                return (tmp.textContent || tmp.innerText || '').trim();
            }

            function doAsk(ta, body){
                const q = (ta.value||'').trim();
                if (!q) return;
                ta.value = '';

                // UI + memoria
                appendMsg('user', escapeHTML(q), body, false);
                const conv = loadConv();
                conv.push({role:'user', text:q, ts:Date.now()});
                saveConv(conv);

                // Placeholder bot con icono de teclado animado
                const waiting = el('div',{class:'phsbot-msg bot'});
                const bubble  = el('div',{class:'phsbot-bubble typing'}, `
                  <span class="phsbot-typing-kb" aria-hidden="true">
                    <svg viewBox="0 0 64 24" xmlns="http://www.w3.org/2000/svg">
                      <rect x="1" y="1" width="62" height="22" rx="4" fill="none" stroke="currentColor" stroke-width="2"/>
                      <rect class="key k1" x="10" y="8" width="10" height="6" rx="1"/>
                      <rect class="key k2" x="24" y="8" width="10" height="6" rx="1"/>
                      <rect class="key k3" x="38" y="8" width="10" height="6" rx="1"/>
                      <rect class="space" x="14" y="16" width="36" height="4" rx="2" fill="currentColor" opacity=".28"/>
                    </svg>
                  </span>
                  <span class="phsbot-typing-label"><?php echo esc_html($U['typing']); ?></span>
                `);
                waiting.appendChild(bubble);
                body.appendChild(waiting);
                autoGrowBody(body);

                const payload = {
                    action: 'phsbot_chat',
                    _ajax_nonce: nonce,
                    q: q,
                    url: window.location.href,
                    cid: CID,
                    history: buildHistoryForAPI()
                };

                fetch(ajaxUrl, {
                    method:'POST',
                    headers:{ 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: new URLSearchParams({ ...payload, history: JSON.stringify(payload.history) }).toString()
                })
                .then(r=>r.json())
                .then(data=>{
                    const ok = !!data.ok;
                    const html = ok ? (data.html || escapeHTML(data.text||'')) : ('<em>'+escapeHTML(data.error||'Error')+'</em>');
                    bubble.classList.remove('typing');
                    bubble.innerHTML = html;

                    if (ok) {
                        const conv2 = loadConv();
                        conv2.push({role:'assistant', text:(data.text||''), html:(data.html||null), ts:Date.now()});
                        saveConv(conv2);
                    }
                    autoGrowBody(body);

                    const top = waiting.offsetTop;
                    body.scrollTo({ top: top - 6, behavior: 'instant' });
                })
                .catch(err=>{
                    bubble.classList.remove('typing');
                    bubble.innerHTML = '<em>Error de red</em>';
                });
            }

            // Exponer global para shortcode inline y auto-inyección
            window.PHSBOT_BUILD = buildUI;
        })();
        </script>
        <?php
    }

    // Markup (modo floating o inline)
    $wrapClass = ($mode === 'inline') ? 'phsbot-inline' : '';
    echo '<div class="phsbot-mount '.$wrapClass.'"></div>';

    // Lanzar UI
    ?>
    <script>window.PHSBOT_BUILD && window.PHSBOT_BUILD(<?php echo wp_json_encode($mode==='inline'?'inline':'floating'); ?>);</script>
    <?php
}}

/** =========================================================
 *  Auto-inyección en footer + shortcode
 *  ======================================================= */
if (!function_exists('phsbot_auto_render')) {
    function phsbot_auto_render(){
        if (is_admin() || wp_doing_ajax() || is_customize_preview()) return;
        if (!phsbot_setting('chat_active', true)) return;
        $pos = (string) phsbot_setting('chat_position', 'bottom-right');
        if ($pos === 'inline') return;
        if (function_exists('phsbot_render_chat_markup')) phsbot_render_chat_markup('floating');
    }
    add_action('wp_footer', 'phsbot_auto_render', 98);
}
if (!shortcode_exists('phsbot')) {
    add_shortcode('phsbot', function($atts){
        ob_start(); phsbot_render_chat_markup('inline'); return ob_get_clean();
    });
}

/** =========================================================
 *  AJAX → OpenAI + KB + Leads hook
 *  ======================================================= */
add_action('wp_ajax_nopriv_phsbot_chat', 'phsbot_ajax_chat');
add_action('wp_ajax_phsbot_chat', 'phsbot_ajax_chat');

function phsbot_ajax_chat(){
    check_ajax_referer('phsbot_chat');

    $api_key = (string) phsbot_setting('openai_api_key', '');
    if (!$api_key){
        wp_send_json(array('ok'=>false, 'error'=>'Falta la OpenAI API Key en Configuración.'));
    }

    $chat   = phsbot_chat_get_settings();
    $q      = isset($_POST['q']) ? wp_unslash((string)$_POST['q']) : '';
    $url    = isset($_POST['url']) ? esc_url_raw($_POST['url']) : '';
    $cid    = isset($_POST['cid']) ? sanitize_text_field($_POST['cid']) : 'cid-fallback';

    // Historial persistente enviado por el front
    $hist   = array();
    if (!empty($_POST['history'])) {
        $raw = json_decode(stripslashes((string)$_POST['history']), true);
        if (is_array($raw)) $hist = $raw;
    }

    // KB
    $kb = (string) get_option(PHSBOT_KB_DOC_OPT, '');

    // (Opcional) fetch rápido de la URL actual (texto plano)
    $live = '';
    if (!empty($chat['allow_live_fetch']) && $url) {
        $allowed = phsbot_setting('allowed_domains', array());
        $host = parse_url($url, PHP_URL_HOST);
        if ($host && is_array($allowed) && (empty($allowed) || in_array($host, $allowed, true))) {
            $r = wp_remote_get($url, array('timeout'=>10));
            if (!is_wp_error($r) && wp_remote_retrieve_response_code($r) === 200) {
                $html = wp_remote_retrieve_body($r);
                $live = wp_strip_all_tags($html);
                $live = wp_trim_words($live, 1200, '…');
            }
        }
    }

    // Construir mensajes para OpenAI
    $lang_prompt = phs_lang_prompt_word();
    $system = "Eres un asistente de Pro Hunting Spain. Responde en {$lang_prompt} con tono {$chat['tone']}. ".
              "Usa primero la Base de Conocimiento (KB) proporcionada. ".
              "Si falta información, dilo claramente. ".
              "Sé útil, preciso y evita inventar datos. Formatea en Markdown simple cuando convenga.";
    if (!empty($chat['prompt_extra'])) $system .= "\n\nInstrucciones extra del admin:\n" . wp_strip_all_tags($chat['prompt_extra']);

    $messages = array(array('role'=>'system','content'=>$system));
    if ($kb)   $messages[] = array('role'=>'system','content' => "KB:\n".$kb);
    if ($live) $messages[] = array('role'=>'system','content' => "Contenido de la URL actual (resumen):\n".$live);

    foreach ($hist as $h) {
        $role = ($h['role']==='assistant') ? 'assistant' : 'user';
        $content = wp_strip_all_tags((string)$h['content']);
        if ($content !== '') $messages[] = array('role'=>$role,'content'=>$content);
    }
    $messages[] = array('role'=>'user','content'=> $q );

    // Llamada OpenAI
    $endpoint = 'https://api.openai.com/v1/chat/completions';
    $body = array(
        'model'       => $chat['model'],
        'messages'    => $messages,
        'temperature' => floatval($chat['temperature']),
        'max_tokens'  => intval($chat['max_tokens']),
    );
    $args = array(
        'timeout' => 60,
        'headers' => array(
            'Authorization' => 'Bearer '.$api_key,
            'Content-Type'  => 'application/json',
        ),
        'body' => wp_json_encode($body),
    );

    $res = wp_remote_post($endpoint, $args);
    if (is_wp_error($res)) {
        wp_send_json(array('ok'=>false, 'error'=>$res->get_error_message()));
    }
    $code = wp_remote_retrieve_response_code($res);
    $raw  = wp_remote_retrieve_body($res);
    if ($code < 200 || $code >= 300) {
        wp_send_json(array('ok'=>false, 'error'=>'OpenAI HTTP '.$code));
    }
    $data = json_decode($raw, true);
    $content = (string)($data['choices'][0]['message']['content'] ?? '');

    // Render opcional HTML/Elementor
    $html = '';
    if ($content) {
        if (!empty($chat['allow_elementor']) && function_exists('do_shortcode')) {
            $content = do_shortcode($content);
        }
        if (!empty($chat['allow_html'])) {
            $html = wp_kses_post($content);
        }
    }

    // Hook a Leads: reevaluar y notificar si aplica
    if (function_exists('phsbot_leads_on_exchange')) {
        phsbot_leads_on_exchange($cid, $q, $content, array('url' => $url));
    }

    if ($html) {
        wp_send_json(array('ok'=>true, 'html'=>$html, 'text'=>wp_strip_all_tags($content)));
    } else {
        wp_send_json(array('ok'=>true, 'text'=>$content));
    }
}

// === Reset de memoria local del chat si el servidor lo ha pedido ===
add_action('wp_footer', function(){
    if (is_admin()) return;
    $ver = intval(get_option('phsbot_client_reset_version', 0));
    ?>
    <script>
    (function(){
      var server = <?php echo $ver ?: 0; ?>;
      try{
        var KEY = 'phsbot_reset_version';
        var cur = parseInt(localStorage.getItem(KEY)||'0',10)||0;
        if (server && server !== cur){
          if (window.localStorage){
            var toDel=[];
            for (var i=0;i<localStorage.length;i++){ toDel.push(localStorage.key(i)); }
            toDel.forEach(function(k){
              var kl=(k||'').toLowerCase();
              if (kl.indexOf('phsbot')>-1 || kl.indexOf('phs_')===0 || kl.indexOf('phs-')===0 || kl.indexOf('chat')>-1){
                try{ localStorage.removeItem(k); }catch(e){}
              }
            });
          }
          if (window.sessionStorage){
            var toDelS=[];
            for (var j=0;j<sessionStorage.length;j++){ toDelS.push(sessionStorage.key(j)); }
            toDelS.forEach(function(k){
              var kl=(k||'').toLowerCase();
              if (kl.indexOf('phsbot')>-1 || kl.indexOf('phs_')===0 || kl.indexOf('phs-')===0 || kl.indexOf('chat')>-1){
                try{ sessionStorage.removeItem(k); }catch(e){}
              }
            });
          }
          if (window.indexedDB){ try{ indexedDB.deleteDatabase('phsbot-db'); }catch(e){} }
          document.cookie.split(';').forEach(function(c){
            var name = c.split('=')[0].trim();
            if (/phs|phsbot|chat/i.test(name)){
              document.cookie = name+'=; Max-Age=0; path=/';
            }
          });
          localStorage.setItem(KEY, String(server));
        }
      }catch(e){}
    })();
    </script>
    <?php
}, 1);