<?php
// File: kb.php
// Base de Conocimiento: PROMPT -> OpenAI -> DOCUMENTO. Sin crawler.
if (!defined('ABSPATH')) exit;

// Carga helpers/constantes comunes
require_once __DIR__ . '/common.php';

// Fallbacks por si common no definió algo
if (!defined('PHSBOT_MENU_SLUG'))     define('PHSBOT_MENU_SLUG', 'phsbot');
if (!defined('PHSBOT_CAP_MENU'))      define('PHSBOT_CAP_MENU', 'read');               // ver menú
if (!defined('PHSBOT_CAP_SETTINGS'))  define('PHSBOT_CAP_SETTINGS', 'manage_options'); // editar

// Opciones de esta sección
if (!defined('PHSBOT_KB_PROMPT_OPT')) define('PHSBOT_KB_PROMPT_OPT', 'phsbot_kb_prompt');
if (!defined('PHSBOT_KB_DOC_OPT'))    define('PHSBOT_KB_DOC_OPT',    'phsbot_kb_document');
if (!defined('PHSBOT_KB_LASTRUN'))    define('PHSBOT_KB_LASTRUN',    'phsbot_kb_last_run');

// Logger local
if (!function_exists('phsbot_kb_log')) {
    function phsbot_kb_log($msg){
        if (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) {
            if (is_array($msg) || is_object($msg)) $msg = print_r($msg, true);
            error_log('[PHSBOT:KB] ' . $msg);
        }
    }
}



// ===== Render de la página =====
if (!function_exists('phsbot_render_kb_minimal')) {
function phsbot_render_kb_minimal() {
    // Guard anti-duplicado (por si algún hook lo llama dos veces)
    static $rendered = false;
    if ($rendered) return;
    $rendered = true;

    phsbot_kb_log('render_kb_minimal init');

    if (!current_user_can(PHSBOT_CAP_SETTINGS)) {
        wp_die(__('No tienes permisos para acceder a esta página.', 'phsbot'), 403);
    }

    // Ensure options exist with autoload = no (heavy content should not autoload)
    if (get_option(PHSBOT_KB_PROMPT_OPT, null) === null) add_option(PHSBOT_KB_PROMPT_OPT, phsbot_kb_minimal_default_prompt(), '', 'no');
    if (get_option(PHSBOT_KB_DOC_OPT, null) === null) add_option(PHSBOT_KB_DOC_OPT, '', '', 'no');
    if (get_option(PHSBOT_KB_LASTRUN, null) === null) add_option(PHSBOT_KB_LASTRUN, '', '', 'no');

    // Estado actual
    $prompt = get_option(PHSBOT_KB_PROMPT_OPT, phsbot_kb_minimal_default_prompt());
    $doc    = get_option(PHSBOT_KB_DOC_OPT, '');
    $last   = get_option(PHSBOT_KB_LASTRUN, '');

    // POST
    $notice = '';
    if (isset($_POST['phsbot_kb_action'])) {
        check_admin_referer('phsbot_kb_minimal_nonce');
        $action     = sanitize_text_field($_POST['phsbot_kb_action']);
        $new_prompt = isset($_POST['phsbot_kb_prompt']) ? wp_kses_post($_POST['phsbot_kb_prompt']) : $prompt;
        $new_doc    = isset($_POST['phsbot_kb_document']) ? wp_kses_post($_POST['phsbot_kb_document']) : $doc;
        $overwrite  = !empty($_POST['phsbot_kb_overwrite']);

        if ($action === 'save') {
            update_option(PHSBOT_KB_PROMPT_OPT, $new_prompt);
            update_option(PHSBOT_KB_DOC_OPT, $new_doc);
            $prompt = $new_prompt; $doc = $new_doc;
            $notice = '<div class="notice notice-success"><p>Guardado correctamente.</p></div>';

        } elseif ($action === 'clear') {
            update_option(PHSBOT_KB_DOC_OPT, '');
            $doc = '';
            $notice = '<div class="notice notice-warning"><p>Documento borrado.</p></div>';

        } elseif ($action === 'generate') {
            update_option(PHSBOT_KB_PROMPT_OPT, $new_prompt);
            $prompt = $new_prompt;

            $api_key = function_exists('phsbot_setting') ? phsbot_setting('openai_api_key', '') : '';
            if (!$api_key) {
                $notice = '<div class="notice notice-error"><p>Falta la <strong>OpenAI API Key</strong> en PhsBot → Configuración.</p></div>';
            } else {
                $result = phsbot_kb_minimal_call_openai($api_key, $prompt);
                if (is_wp_error($result)) {
                    $msg = esc_html($result->get_error_message());
                    $notice = '<div class="notice notice-error"><p>Error al consultar OpenAI: ' . $msg . '</p></div>';
                } else {
                    $doc = ($overwrite || $doc === '') ? $result : (rtrim($doc) . "\n\n---\n\n" . ltrim($result));
                    update_option(PHSBOT_KB_DOC_OPT, $doc);
                    $ts = current_time('mysql');
                    update_option(PHSBOT_KB_LASTRUN, $ts);
                    $last = $ts;
                    $notice = '<div class="notice notice-success"><p>Documento actualizado desde ChatGPT.</p></div>';
                }
            }
        }
    }
    ?>
    <div class="wrap">
        <h1>PhsBot — Base de Conocimiento</h1>
        <p class="description">Escribe/ajusta el PROMPT, pulsa <em>Generar</em> y pegaremos la respuesta de ChatGPT en el documento.</p>
        <?php echo $notice; ?>

        <form method="post">
            <?php wp_nonce_field('phsbot_kb_minimal_nonce'); ?>
            <input type="hidden" name="page" value="phsbot-kb">

            <table class="form-table" role="presentation">
                <tbody>
                    <tr>
                        <th scope="row"><label for="phsbot_kb_prompt">PROMPT</label></th>
                        <td>
                            <textarea id="phsbot_kb_prompt" name="phsbot_kb_prompt" rows="12" style="width:100%;max-width:980px;"><?php echo esc_textarea($prompt); ?></textarea>
                            <p class="description">Se envía tal cual a ChatGPT usando la API Key guardada en <em>Configuración</em>.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Opciones</th>
                        <td>
                            <label><input type="checkbox" name="phsbot_kb_overwrite" value="1"> Sobrescribir documento existente</label>
                            <?php if ($last): ?>
                                <p class="description">Última generación: <?php echo esc_html($last); ?></p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row"><label for="phsbot_kb_document">Documento (resultado)</label></th>
                        <td>
                            <textarea id="phsbot_kb_document" name="phsbot_kb_document" rows="18" style="width:100%;max-width:980px;"><?php echo esc_textarea($doc); ?></textarea>
                            <p class="description">Editable. Puedes corregir antes de <em>Guardar</em>.</p>
                        </td>
                    </tr>
                </tbody>
            </table>

            <p>
                <button class="button button-primary" name="phsbot_kb_action" value="generate">Generar (preguntar a ChatGPT)</button>
                <button class="button" name="phsbot_kb_action" value="save">Guardar</button>
                <button class="button button-link-delete" name="phsbot_kb_action" value="clear" onclick="return confirm('¿Vaciar documento actual?');">Vaciar</button>
            </p>
        </form>
    </div>
    <?php
}}
/* ===== FIN render ===== */

// Prompt por defecto
if (!function_exists('phsbot_kb_minimal_default_prompt')) {
function phsbot_kb_minimal_default_prompt() {
    $home = home_url('/');
    $host = parse_url($home, PHP_URL_HOST);
    $tpl = <<<EOT
Eres un analista web experto en marketing para turismo cinegético.
Genera una Base de Conocimiento exhaustiva sobre el sitio "{$host}" (URL base: {$home}), con apartados:
- Quiénes somos
- Productos/Servicios (deducidos por contexto)
- Diferenciales
- Proceso de contratación
- Preguntas frecuentes
- Contacto (incluye URL/es de contacto si aparecen)
- Ubicaciones/zonas y temporadas
- Políticas relevantes
- Enlaces internos clave (anchor → URL)
- Llamadas a la acción

Formato: Markdown con H2/H3 y listas. Si falta info, indica "No observado".
Ignora textos repetidos de plantillas (header/footer/menús).
EOT;
    return $tpl;
}}

// Llamada a OpenAI
if (!function_exists('phsbot_kb_minimal_call_openai')) {
function phsbot_kb_minimal_call_openai($api_key, $prompt) {
    $endpoint = 'https://api.openai.com/v1/chat/completions';
    $model    = 'gpt-4o-mini';
    $system   = "Responde en español, claro y orientado a marketing. Si no hay datos, dilo explícitamente.";

    $body = array(
        'model' => $model,
        'messages' => array(
            array('role' => 'system', 'content' => $system),
            array('role' => 'user',   'content' => $prompt),
        ),
        'temperature' => 0.2,
        'max_tokens'  => 4000,
    );

    $res = wp_remote_post($endpoint, array(
        'timeout' => 90,
        'headers' => array(
            'Authorization' => 'Bearer ' . $api_key,
            'Content-Type'  => 'application/json',
        ),
        'body' => wp_json_encode($body),
    ));
    if (is_wp_error($res)) return $res;

    $code = wp_remote_retrieve_response_code($res);
    if ($code < 200 || $code >= 300) {
        $err = wp_remote_retrieve_body($res);
        phsbot_kb_log('OpenAI HTTP ' . $code . ': ' . $err);
        return new WP_Error('kb_openai_http', 'OpenAI HTTP ' . $code . ': ' . $err);
    }

    $data = json_decode(wp_remote_retrieve_body($res), true);
    if (!$data || empty($data['choices'][0]['message']['content'])) {
        phsbot_kb_log('Respuesta inesperada de OpenAI');
        return new WP_Error('kb_openai_parse', 'Respuesta inesperada del API de OpenAI.');
    }
    return (string)$data['choices'][0]['message']['content'];
}}

// Alias compatibilidad (si algún menú/hook llama al nombre antiguo)
if (!function_exists('phsbot_render_kb_page')) {
function phsbot_render_kb_page() {
    return phsbot_render_kb_minimal();
}}