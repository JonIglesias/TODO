<?php
// File: logs.php (PHSBOT) — solo render y utilidades; los submenús los registra menu.php
if (!defined('ABSPATH')) exit;
require_once __DIR__ . '/common.php';

if (!function_exists('phsbot_render_logs_page')) {
    function phsbot_render_logs_page() {
        $cap = (is_multisite() && is_network_admin()) ? 'manage_network_options' : 'manage_options';
        if (!current_user_can($cap)) wp_die(__('No tienes permisos para acceder a esta página.', 'phsbot'), 403);

        $log_path = WP_CONTENT_DIR . '/debug.log';
        $action   = isset($_REQUEST['phs_action']) ? sanitize_text_field($_REQUEST['phs_action']) : '';
        $nonce    = isset($_REQUEST['_wpnonce']) ? $_REQUEST['_wpnonce'] : '';

        if ($action === 'download' && wp_verify_nonce($nonce, 'phsbot_logs_nonce')) {
            if (file_exists($log_path)) {
                header('Content-Type: text/plain; charset=utf-8');
                header('Content-Disposition: attachment; filename="debug.log"');
                header('Content-Length: ' . filesize($log_path));
                readfile($log_path);
                exit;
            } else {
                wp_die('No existe wp-content/debug.log');
            }
        }
        if ($action === 'clear' && wp_verify_nonce($nonce, 'phsbot_logs_nonce')) {
            if (file_exists($log_path) && is_writable($log_path)) {
                $fp = @fopen($log_path, 'w');
                if ($fp) { fclose($fp); $cleared = true; }
            }
        }

        $query = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        $lines = isset($_GET['lines']) ? max(50, min(5000, intval($_GET['lines']))) : 800;
        $data  = phsbot_tail_file($log_path, $lines);
        if ($query !== '' && !empty($data['content'])) {
            $filtered = array();
            foreach ($data['content'] as $ln) {
                if (stripos($ln, $query) !== false) $filtered[] = $ln;
            }
            $data['content'] = $filtered;
        }

        $checks = array(
            'Plugin cargado'               => class_exists('PHSBOT_Plugin') ? 'sí' : 'no',
            'Archivo common.php'           => function_exists('phsbot_settings') ? 'sí' : 'no',
            'Menú PhsBot (slug)'           => defined('PHSBOT_MENU_SLUG') ? PHSBOT_MENU_SLUG : '(no definido)',
            'Página ajustes (slug)'        => defined('PHSBOT_PAGE_SLUG') ? PHSBOT_PAGE_SLUG : '(no definido)',
            'Hook screen actual'           => function_exists('get_current_screen') && get_current_screen() ? get_current_screen()->id : '(desconocido)',
            'Multisite'                    => is_multisite() ? 'sí' : 'no',
            'Network admin'                => (is_multisite() && is_network_admin()) ? 'sí' : 'no',
            'Usuario puede manage_options' => current_user_can('manage_options') ? 'sí' : 'no',
            'Usuario puede manage_network_options' => current_user_can('manage_network_options') ? 'sí' : 'no',
            'Ruta debug.log'               => $log_path,
            'Exists debug.log'             => file_exists($log_path) ? 'sí' : 'no',
            'Writable debug.log'           => file_exists($log_path) ? (is_writable($log_path) ? 'sí' : 'no') : '(n/a)',
            'WP_DEBUG'                     => (defined('WP_DEBUG') && WP_DEBUG) ? 'true' : 'false',
            'WP_DEBUG_LOG'                 => (defined('WP_DEBUG_LOG') && WP_DEBUG_LOG) ? 'true' : 'false',
            'WP_DEBUG_DISPLAY'             => (defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY) ? 'true' : 'false',
        );

        $nonce_dl = wp_create_nonce('phsbot_logs_nonce');
        ?>
        <div class="wrap">
            <h1>PhsBot — Logs</h1>

            <h2 class="title">Chequeos rápidos</h2>
            <table class="widefat striped" style="max-width:900px">
                <tbody>
                <?php foreach ($checks as $k => $v): ?>
                    <tr><td style="width:320px"><strong><?php echo esc_html($k); ?></strong></td><td><?php echo esc_html($v); ?></td></tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h2 class="title" style="margin-top:24px">debug.log</h2>
            <form method="get" style="margin:10px 0">
                <input type="hidden" name="page" value="phsbot-logs">
                <input type="text" name="s" value="<?php echo esc_attr($query); ?>" placeholder="Filtrar por texto..." style="width:300px">
                <input type="number" name="lines" value="<?php echo esc_attr($lines); ?>" min="50" max="5000" step="50" style="width:120px">
                <button class="button">Aplicar</button>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=phsbot-logs')); ?>">Reset</a>
                <?php if (file_exists($log_path)): ?>
                    <a class="button button-primary" href="<?php echo esc_url(add_query_arg(array('phs_action'=>'download','_wpnonce'=>$nonce_dl), admin_url('admin.php?page=phsbot-logs'))); ?>">Descargar</a>
                    <a class="button button-link-delete" href="<?php echo esc_url(add_query_arg(array('phs_action'=>'clear','_wpnonce'=>$nonce_dl), admin_url('admin.php?page=phsbot-logs'))); ?>" onclick="return confirm('¿Vaciar debug.log?');">Vaciar</a>
                <?php endif; ?>
            </form>

            <?php if (isset($cleared) && $cleared): ?>
                <div class="notice notice-success"><p>debug.log vaciado.</p></div>
            <?php endif; ?>

            <?php if (!$data['exists']): ?>
                <div class="notice notice-warning"><p>No existe <code>wp-content/debug.log</code>. Activa WP_DEBUG en <code>wp-config.php</code>.</p></div>
            <?php else: ?>
                <p><em>Mostrando las últimas <?php echo intval($lines); ?> líneas<?php echo $query ? ' filtradas por “'.esc_html($query).'”' : ''; ?>.</em></p>
                <textarea readonly style="width:100%;max-width:1200px;height:520px;font-family:Menlo,Consolas,monospace"><?php
                    echo esc_textarea(implode("", $data['content']));
                ?></textarea>
            <?php endif; ?>
        </div>
        <?php
    }
}

if (!function_exists('phsbot_tail_file')) {
    function phsbot_tail_file($filepath, $lines = 800) {
        $result = array('exists' => false, 'content' => array());
        if (!file_exists($filepath)) return $result;
        $result['exists'] = true;

        $f = @fopen($filepath, "rb");
        if (!$f) return $result;

        $buffer = '';
        $chunkSize = 4096;
        $pos = -1;
        $lineCount = 0;

        fseek($f, 0, SEEK_END);
        $filesize = ftell($f);

        while ($lineCount < $lines && -$pos < $filesize) {
            $step = min($chunkSize, $filesize + $pos);
            $pos -= $step;
            fseek($f, $pos, SEEK_END);
            $chunk = fread($f, $step);
            $buffer = $chunk . $buffer;
            $lineCount = substr_count($buffer, "\n");
        }
        fclose($f);

        $arr = explode("\n", $buffer);
        $arr = array_slice($arr, -$lines);
        foreach ($arr as $i => $ln) $arr[$i] = rtrim($ln) . "\n";

        $result['content'] = $arr;
        return $result;
    }
}
