<?php
// File: voice_ui.php
if (!defined('ABSPATH')) exit;

/**
 * Carga CSS/JS del módulo de voz sólo en el front cuando el chat está activo.
 */
add_action('wp_enqueue_scripts', function () {
    if (is_admin()) return;
    if (!function_exists('phsbot_setting') || !phsbot_setting('chat_active', true)) return;

    $ver = defined('PHSBOT_VERSION') ? PHSBOT_VERSION : '1.0';
    wp_enqueue_style('phs-voice-ui', plugins_url('voice_ui.css', __FILE__), array(), $ver);
    wp_enqueue_script('phs-voice-ui', plugins_url('voice_ui.js', __FILE__), array(), $ver, true);
});

/**
 * Inyecta el contenedor de la UI y lo mueve a la cabecera del chat.
 */
add_action('wp_footer', function () {
    if (is_admin()) return;
    ?>
    <div id="phs-voice-ui" class="phs-voice-ui" style="display:none">
      <div class="phs-voice-toggle-wrap" title="Activar dictado por voz">
        <!-- Toggle skeuomórfico (mantiene IDs/clases para el JS) -->
        <label class="phs-toggle phs-skeuo" id="phs-voice-toggle" aria-label="Activar dictado">
          <input type="checkbox" id="phs-voice-cb" />
          <div class="track">
            <span class="on">Dictado On</span>
            <span class="off">Dictado Off</span>
          </div>
          <i class="thumb" aria-hidden="true"></i>
        </label>
      </div>
    </div>

    <script>
    (function(){
      // Espera a que exista la cabecera del chat y mueve dentro la UI
      function mount(){
        var head = document.querySelector('#phsbot-root .phsbot-head');
        var ui   = document.getElementById('phs-voice-ui');
        if (!head || !ui) return false;

        ui.style.display = 'block';
        head.insertBefore(ui, head.firstChild);

        // Evita que al hacer click en la UI se cierre el chat (la cabecera hace toggle)
        ui.addEventListener('click', function(e){ e.stopPropagation(); }, true);
        ui.addEventListener('mousedown', function(e){ e.stopPropagation(); }, true);
        return true;
      }
      (function wait(){ if (!mount()) setTimeout(wait, 200); })();
    })();
    </script>
    <?php
});
