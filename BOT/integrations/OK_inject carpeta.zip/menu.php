<?php
// File: menu.php
if (!defined('ABSPATH')) exit;

add_action('admin_menu', function () {
    // === CARGA EXPLÍCITA DE MÓDULOS ANTES DE REGISTRAR SUBMENÚS ===
    $base_dir = plugin_dir_path(__FILE__);
    if (file_exists($base_dir . 'inject/inject.php')) {
        require_once $base_dir . 'inject/inject.php';
    }

    $cap_menu      = defined('PHSBOT_CAP_MENU')     ? PHSBOT_CAP_MENU     : 'read';
    $cap_settings  = defined('PHSBOT_CAP_SETTINGS') ? PHSBOT_CAP_SETTINGS : 'manage_options';
    $menu_slug     = defined('PHSBOT_MENU_SLUG')    ? PHSBOT_MENU_SLUG    : 'phsbot';

    // Top-level
    add_menu_page(
        'PHSBot',
        'PHSBot',
        $cap_menu,
        $menu_slug,
        'phsbot_render_settings',
        'dashicons-format-chat',
        60
    );

    // Submenú principal (mismo slug que el parent)
    add_submenu_page(
        $menu_slug,
        'Configuración',
        'Configuración',
        $cap_settings,
        $menu_slug,
        'phsbot_render_settings'
    );

    // Submenú: Chat & Widget (con fallback)
    add_submenu_page(
        $menu_slug,
        'Chat & Widget',
        'Chat & Widget',
        $cap_settings,
        'phsbot-chat',
        function () {
            if (function_exists('phsbot_render_chat_settings')) { phsbot_render_chat_settings(); return; }
            if (function_exists('phsbot_render_chat_page')) { phsbot_render_chat_page(); return; }
            echo '<div class="wrap"><h1>Chat &amp; Widget</h1><p>No se encontró el módulo de chat.</p></div>';
        }
    );

    // Submenú: Inyecciones (siempre visible; llama si existe, muestra fallback si no)
    add_submenu_page(
        $menu_slug,
        'Inyecciones',
        'Inyecciones',
        $cap_settings,
        'phsbot-inject',
        function () {
            // Cubre distintas firmas posibles para compat
            if (function_exists('phsbot_render_inject_admin')) { phsbot_render_inject_admin(); return; }
            if (function_exists('phsbot_render_inject_page')) { phsbot_render_inject_page(); return; }
            if (function_exists('phsbot_inject_admin_page')) { phsbot_inject_admin_page(); return; }
            echo '<div class="wrap"><h1>Inyecciones</h1><p>No se encontró el módulo de Inyecciones.</p></div>';
        }
    );

    // Submenú: Base de Conocimiento (con fallback)
    add_submenu_page(
        $menu_slug,
        'Base de Conocimiento',
        'Base de Conocimiento',
        $cap_settings,
        'phsbot-kb',
        function () {
            if (function_exists('phsbot_render_kb_admin')) { phsbot_render_kb_admin(); return; }
            if (function_exists('phsbot_render_kb_minimal')) { phsbot_render_kb_minimal(); return; }
            if (function_exists('phsbot_render_kb_page')) { phsbot_render_kb_page(); return; }
            echo '<div class="wrap"><h1>Base de Conocimiento</h1><p>No se encontró el módulo de KB.</p></div>';
        }
    );

    // Submenú: Leads & Scoring
    if (function_exists('phsbot_leads_admin_page')) {
        add_submenu_page(
            $menu_slug,
            'Leads & Scoring',
            'Leads & Scoring',
            $cap_settings,
            'phsbot-leads',
            'phsbot_leads_admin_page'
        );
    }

    // Submenú: Integraciones
    if (function_exists('phsbot_render_integrations_page')) {
        add_submenu_page(
            $menu_slug,
            'Integraciones',
            'Integraciones',
            $cap_settings,
            'phsbot-integrations',
            'phsbot_render_integrations_page'
        );
    }

    // Submenú: Logs
    if (function_exists('phsbot_render_logs_page')) {
        add_submenu_page(
            $menu_slug,
            'Logs',
            'Logs',
            $cap_settings,
            'phsbot-logs',
            'phsbot_render_logs_page'
        );
    }

    // Limpia posibles menús “fantasma” de versiones antiguas
    $legacy = array('phsbot-settings','phsbot_chat','phsbot-chat-legacy','phsbot_inject','phsbot_kb_page','phsbot_leads','phsbot_leads_old');
    foreach ($legacy as $slug) {
        remove_submenu_page($menu_slug, $slug);
    }
}, 60);