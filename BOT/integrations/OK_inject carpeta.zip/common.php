<?php
// File: common.php
if (!defined('ABSPATH')) exit;

/* ===========================================================================
 *  PHSBot – Common Loader (compatible con estructura vieja y nueva)
 *  - Define utilidades mínimas y carga de módulos.
 *  - Carga módulos tanto en formato "archivo suelto" (/chat.php)
 *    como en formato "carpeta por módulo" (/chat/chat.php).
 *  - Incluye carga opcional de parches (patches/hardening.php).
 *  - Aplica filtro 'phsbot_modules' para personalización.
 * ========================================================================== */


/* ===========================================================================
 *  CONSTANTES BÁSICAS (no pisa si ya existen)
 * ========================================================================== */

if (!defined('PHSBOT_DIR'))  define('PHSBOT_DIR',  plugin_dir_path(__FILE__));
if (!defined('PHSBOT_URL'))  define('PHSBOT_URL',  plugins_url('', __FILE__));
if (!defined('PHSBOT_SLUG')) define('PHSBOT_SLUG', 'phsbot');


/* ===========================================================================
 *  I18N: Cargar textdomain (si existe carpeta /languages)
 * ========================================================================== */

if (!function_exists('phsbot_load_textdomain')) {
    function phsbot_load_textdomain() {
        load_plugin_textdomain('phsbot', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }
}
add_action('init', 'phsbot_load_textdomain');


/* ===========================================================================
 *  CARGA DE PARCHES (opcional)
 * ========================================================================== */

if (!function_exists('phsbot_load_patches')) {
    function phsbot_load_patches() {
        $patch = PHSBOT_DIR . 'patches/hardening.php';
        if (file_exists($patch)) {
            require_once $patch;
        }
    }
}
phsbot_load_patches();


/* ===========================================================================
 *  CARGADOR DE MÓDULOS: COMPAT ARCHIVO SUELTO Y CARPETA
 * ========================================================================== */

if (!function_exists('phsbot_load_module')) {
    /**
     * phsbot_load_module
     * -----------------------------------------------------------------------
     * Intenta cargar un módulo desde:
     *   1) /<mod>.php                (estructura antigua)
     *   2) /<mod>/<mod>.php          (estructura nueva)
     *   3) /modules/<mod>.php        (legacy muy antiguo)
     * -----------------------------------------------------------------------
     * @param string $mod
     * @return bool loaded
     */
    function phsbot_load_module($mod) {
        $base = PHSBOT_DIR;

        $paths = array(
            $base . $mod . '.php',
            $base . $mod . '/' . $mod . '.php',
            $base . 'modules/' . $mod . '.php',
        );

        foreach ($paths as $p) {
            if (file_exists($p)) {
                require_once $p;
                return true;
            }
        }
        return false;
    }
}


/* ===========================================================================
 *  LISTA DE MÓDULOS A CARGAR (puede personalizarse con el filtro)
 * ========================================================================== */

$__phsbot_modules = array(
    'menu',
    'chat',
    'kb',
    'leads',
    'integrations',
    'inject',        // ahora en /inject/inject.php (pero compatible con /inject.php)
    'logs',
    'formuchat',
    'styles',
    'voice_ui',
);

/**
 * Permite modificar la lista desde otros plugins/temas:
 *   add_filter('phsbot_modules', function($mods){ ... return $mods; });
 */
$__phsbot_modules = apply_filters('phsbot_modules', $__phsbot_modules);


/* ===========================================================================
 *  CARGA EN ORDEN
 * ========================================================================== */

foreach ($__phsbot_modules as $__m) {
    phsbot_load_module($__m);
}
unset($__phsbot_modules, $__m);


/* ===========================================================================
 *  UTILIDADES LIGERAS (opcionales, no pisan si existen)
 * ========================================================================== */

if (!function_exists('phsbot_array_get')) {
    /**
     * phsbot_array_get
     * -----------------------------------------------------------------------
     * Helper para leer arrays con valor por defecto.
     * -----------------------------------------------------------------------
     * @param array $arr
     * @param string|int $key
     * @param mixed $default
     * @return mixed
     */
    function phsbot_array_get($arr, $key, $default = null) {
        return (is_array($arr) && isset($arr[$key])) ? $arr[$key] : $default;
    }
}

if (!function_exists('phsbot_is_admin_screen')) {
    /**
     * phsbot_is_admin_screen
     * -----------------------------------------------------------------------
     * Devuelve true si estás en una pantalla de admin con un slug concreto.
     * -----------------------------------------------------------------------
     * @param string $needle
     * @return bool
     */
    function phsbot_is_admin_screen($needle) {
        if (!is_admin()) return false;
        if (function_exists('get_current_screen')) {
            $s = get_current_screen();
            if ($s && !empty($s->id)) {
                return (stripos($s->id, $needle) !== false);
            }
        }
        if (isset($_GET['page'])) {
            $p = strtolower(sanitize_text_field(wp_unslash($_GET['page'])));
            return (stripos($p, $needle) !== false);
        }
        return false;
    }
}