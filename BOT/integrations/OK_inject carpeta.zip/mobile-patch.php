<?php
// File: mobile-patch.php — Parche SOLO móvil para el chat
if (!defined('ABSPATH')) exit;

/* Lee la preferencia de posición para respetar left/right */
if (!function_exists('phsbot_setting')) {
  function phsbot_setting($key, $default=null){
    $opt = get_option('phsbot_settings', array());
    return array_key_exists($key, $opt) ? $opt[$key] : $default;
  }
}
$pos     = (string) phsbot_setting('chat_position', 'bottom-right');
$is_left = (strpos($pos, 'left') !== false);
$side_x  = $is_left ? 'left' : 'right';

/* ===== CSS SOLO MÓVIL ===== */
add_action('wp_head', function() use ($side_x){ ?>
<style id="phsbot-mobile-patch-css">
@media (max-width: 767.98px){

  /* Launcher flotante en móvil */
  .phsbot-launcher{
    position: fixed !important;
    <?php echo $side_x; ?>: 14px !important;
    bottom: 14px !important;
    z-index: 2147483645 !important;
  }

  /* El root cerrado no debe interceptar clics */
  #phsbot-root.phsbot-wrap{
    pointer-events: none !important;
  }

  /* Cuando está abierto, el root pasa a fixed y se maneja por JS */
  html.phs-open #phsbot-root.phsbot-wrap{
    pointer-events: auto !important;
    position: fixed !important;
    /* left/right se fijan en JS según teclado; aquí valores de seguridad */
    <?php echo $side_x; ?>: 14px !important;
    top: 14px !important;
    width: min(92vw, 520px) !important;
    max-width: 92vw !important;
    z-index: 2147483647 !important;
  }

  /* Tarjeta en layout columna para anclar input abajo */
  html.phs-open #phsbot-root .phsbot-card{
    display: flex !important;
    flex-direction: column !important;
    min-height: 280px !important;
    height: auto;             /* la altura se fija por JS */
    overflow: hidden !important;
  }

  /* Área scrollable de mensajes */
  html.phs-open #phsbot-root .phsbot-body{
    flex: 1 1 auto !important;
    min-height: 0 !important;
    overflow-y: auto !important;
    -webkit-overflow-scrolling: touch !important;
  }

  /* Barra de entrada pegada abajo + safe area */
  html.phs-open #phsbot-root .phsbot-input{
    flex: 0 0 auto !important;
    padding-bottom: max(10px, env(safe-area-inset-bottom)) !important;
    background: #fff;
  }

  /* Oculta la "X" nativa de escritorio en móvil (evita botón doble) */
  html.phs-open #phsbot-root .phsbot-head > div:last-child{
    display: none !important;
  }

  /* Botón de cierre redondo y grande dentro de la cabecera */
  html.phs-open #phsbot-root .phsbot-head{
    position: relative !important;
    padding-right: 76px !important; /* hueco para el botón */
  }
  html.phs-open #phsbot-root .phsbot-close-btn{
    position: absolute !important;
    top: 6px; right: 6px;
    width: 48px; height: 48px;
    border-radius: 999px;
    border: 0;
    background: #000; color: #fff;
    font-weight: 900; font-size: 30px; line-height: 1;
    display: flex; align-items: center; justify-content: center;
    box-shadow: 0 2px 8px rgba(0,0,0,.35);
    cursor: pointer; user-select: none;
  }
  html.phs-open #phsbot-root .phsbot-close-btn:active{ transform: scale(.98); }

  /* Overlay .8 cubriendo todo */
  .phsbot-overlay{ display:none; }
  html.phs-open .phsbot-overlay{
    display:block; position:fixed; inset:0;
    background: rgba(0,0,0,.8);
    z-index: 2147483646;
    pointer-events: auto;
    touch-action: none;
  }

  /* Oculta el launcher cuando está abierto */
  html.phs-open .phsbot-launcher{ display: none !important; }

  /* Bloquea scroll de la página al abrir */
  html.phs-open, html.phs-open body{ overflow: hidden !important; }
}
</style>
<?php }, 9999);

/* ===== JS SOLO MÓVIL ===== */
add_action('wp_footer', function() use ($side_x){ ?>
<script id="phsbot-mobile-patch-js">
(function(){
  var MQ = window.matchMedia('(max-width: 767.98px)');
  if (!MQ.matches) return;

  var SIDE_X = "<?php echo esc_js($side_x); ?>";

  var root, card, head, body, inputBar, textarea, overlay, mounted=false;

  function qs(s,ctx){ return (ctx||document).querySelector(s); }
  function raf(fn){ return requestAnimationFrame(fn); }

  function ensureNodes(){
    root     = qs('#phsbot-root');
    card     = root ? qs('.phsbot-card', root) : null;
    head     = card ? qs('.phsbot-head', card) : null;
    body     = root ? qs('.phsbot-body', root) : null;
    inputBar = root ? qs('.phsbot-input', root) : null;
    textarea = root ? qs('#phsbot-q', root) : null;
    return !!(root && card && head && body && inputBar);
  }

  function ensureOverlay(){
    if (overlay) return overlay;
    overlay = document.createElement('div');
    overlay.className = 'phsbot-overlay';
    document.body.appendChild(overlay);
    overlay.addEventListener('click', closeChat, {passive:true});
    return overlay;
  }
  function removeOverlay(){
    if (!overlay) return;
    try{ overlay.removeEventListener('click', closeChat); }catch(e){}
    if (overlay.parentNode) overlay.parentNode.removeChild(overlay);
    overlay = null;
  }

  function closeChat(){ if (head) head.dispatchEvent(new Event('click', {bubbles:true})); }

  /* Altura disponible EN PIXELES usando visualViewport (descarta teclado) */
  function availableHeightPx(){
    var vv = window.visualViewport;
    var vh = vv && vv.height ? vv.height : window.innerHeight;
    var marginTop = 14, marginBottom = 14;
    return Math.max(280, Math.round(vh - (marginTop + marginBottom)));
  }

  /* Recoloca el root al área visible y fija alturas internas */
  function sizeCard(){
    if (!root || !card || !head || !body || !inputBar) return;

    var vv = window.visualViewport;
    var topOff = vv && typeof vv.offsetTop === 'number' ? vv.offsetTop : 0; // cuando aparece teclado
    var H = availableHeightPx();

    /* Posición: fixed anclado a lado preferido y desplazado con translateY por offsetTop */
    root.style.position = 'fixed';
    root.style.top = '0';
    root.style.bottom = 'auto';
    root.style.transform = 'translateY(' + (topOff + 14) + 'px)'; // 14px de margen superior
    if (SIDE_X === 'left') { root.style.left = '14px'; root.style.right = 'auto'; }
    else { root.style.right = '14px'; root.style.left = 'auto'; }
    root.style.width = 'min(92vw, 520px)';
    root.style.maxWidth = '92vw';
    root.style.zIndex = '2147483647';

    /* Altura total de tarjeta + altura útil del body (scroll) */
    card.style.height = H + 'px';
    var bodyH = H - head.offsetHeight - inputBar.offsetHeight - 2;
    body.style.maxHeight = (bodyH > 120 ? bodyH : 120) + 'px';

    raf(scrollToBottom);
  }

  function scrollToBottom(){ if (body) body.scrollTop = body.scrollHeight; }

  /* ===== NUEVO: anclar al INICIO del párrafo del ÚLTIMO mensaje del BOT ===== */
  function scrollToBotMsgTop(msg, scroller){
    if (!msg || !scroller) return;
    var bubble = msg.querySelector('.phsbot-bubble') || msg;
    var anchor = bubble.querySelector('p,li,div,pre,code,h1,h2,h3,h4,h5,h6') || bubble;
    // offset dentro del contenedor scrollable
    var top = anchor.getBoundingClientRect().top - scroller.getBoundingClientRect().top + scroller.scrollTop;
    scroller.scrollTop = Math.max(0, top - 8);
  }

  function syncOpen(){
    if (!card) return;
    var open = card.getAttribute('data-open') === '1';
    document.documentElement.classList.toggle('phs-open', open);
    if (open){
      ensureOverlay();
      root.style.pointerEvents = 'auto';
      sizeCard();
      // Reforzar tras animaciones/render
      setTimeout(sizeCard, 50);
      setTimeout(sizeCard, 250);
    } else {
      removeOverlay();
      root.style.pointerEvents = 'none';
      // Limpieza de estilos en cierre
      root.style.transform = '';
    }
  }

  function mount(){
    if (mounted) return;
    var tries = 0;
    (function wait(){
      if (!ensureNodes()){
        if (++tries < 80) return setTimeout(wait, 150);
        return;
      }

      // Oculta la X nativa de escritorio y añade nuestro botón circular
      var nativeX = head.lastElementChild; if (nativeX) nativeX.style.display='none';
      var btn = head.querySelector('.phsbot-close-btn');
      if (!btn){
        btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'phsbot-close-btn';
        btn.setAttribute('aria-label','Cerrar chat');
        btn.textContent = '×';
        head.appendChild(btn);
        btn.addEventListener('click', function(e){ e.stopPropagation(); closeChat(); });
      }

      // Observa cambios de "abierto/cerrado"
      var mo = new MutationObserver(function(list){
        for (var i=0; i<list.length; i++){
          if (list[i].attributeName === 'data-open' || list[i].attributeName === 'style'){
            syncOpen(); break;
          }
        }
      });
      mo.observe(card, {attributes:true, attributeFilter:['data-open','style']});

      // Recalcula ante teclado/orientación
      var resizer = function(){ sizeCard(); };
      window.addEventListener('resize', resizer, {passive:true});
      if (window.visualViewport){
        visualViewport.addEventListener('resize', resizer);
        visualViewport.addEventListener('scroll', resizer);
      }

      // Al escribir, mantener lo último a la vista
      if (textarea){
        textarea.addEventListener('focus', function(){
          setTimeout(function(){ sizeCard(); scrollToBottom(); }, 50);
        }, {passive:true});
        textarea.addEventListener('blur', resizer, {passive:true});
        textarea.addEventListener('input', function(){ raf(scrollToBottom); }, {passive:true});
      }

      /* ===== MODIFICADO: Auto‑scroll al INICIO del mensaje del BOT ===== */
      var throttle;
      var moBody = new MutationObserver(function(mList){
        // Debounce para agrupar cambios en el mismo tick (placeholder + contenido)
        if (throttle) cancelAnimationFrame(throttle);
        throttle = requestAnimationFrame(function(){
          if (!body) return;

          // Busca el último mensaje del bot
          var nodes = body.querySelectorAll('.phsbot-msg.bot');
          var lastBot = nodes.length ? nodes[nodes.length - 1] : null;

          if (lastBot) {
            // Anclar al inicio del primer bloque del mensaje del bot
            scrollToBotMsgTop(lastBot, body);
          } else {
            // Si no hay mensaje de bot, baja al final (caso mensajes de usuario)
            scrollToBottom();
          }
        });
      });
      moBody.observe(body, {
        childList: true,
        subtree: true,
        characterData: true // por si se actualiza el contenido sin añadir nodos
      });

      // Estado inicial
      root.style.pointerEvents = (card.getAttribute('data-open') === '1') ? 'auto' : 'none';
      syncOpen();
      mounted = true;
    })();
  }

  function unmount(){
    removeOverlay();
    document.documentElement.classList.remove('phs-open');
    mounted = false;
  }

  // Arranque y cambio de media‑query
  if (MQ.matches) mount();
  if (MQ.addEventListener){
    MQ.addEventListener('change', function(e){ e.matches ? mount() : unmount(); });
  } else {
    MQ.addListener(function(e){ e.matches ? mount() : unmount(); });
  }
})();
</script>
<?php }, 9999);